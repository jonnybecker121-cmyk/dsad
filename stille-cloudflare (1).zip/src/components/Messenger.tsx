import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft, Check, CheckCheck, EyeOff, Fingerprint, Flame, Hourglass, ImagePlus, KeyRound, Lock, LogOut, MessageSquare, Plus,
  Search, Send, Server, Settings as SettingsIcon, ShieldCheck, SmilePlus, Timer, Trash2, UserCog, UserPlus, UserRound,
} from "lucide-react";
import * as C from "../lib/crypto";
import { isVerified, setVerified, shortKey } from "../lib/contact";
import { fileToDataUrl } from "../lib/image";
import { decodePayload, encodePayload, previewOf, type Payload } from "../lib/payload";
import * as S from "../lib/server";
import { useConvKey, useDecrypted, useSession } from "../lib/session";
import { Avatar, Button, Chip, Label, Modal, Toggle, cx, fmtDay, fmtRel, fmtTime, inputCls, useToast } from "./ui";
import Admin from "./Admin";
import AddContact from "./AddContact";
import { PairShow } from "./Pair";
import ProfileView from "./Profile";
import { StoriesBar } from "./Stories";

type View = "chats" | "profile" | "admin" | "settings";

const TTLS: [number, string][] = [[0, "Aus"], [30, "30 Sek."], [300, "5 Min."], [3600, "1 Std."], [86400, "24 Std."], [604800, "7 Tage"]];
const ttlLabel = (s: number) => TTLS.find(([v]) => v === s)?.[1] ?? `${s}s`;
const EMOJIS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

function useTick(ms: number) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setN((x) => x + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

export default function Messenger() {
  const { me, logout } = useSession();
  const db = S.useDB();
  const [view, setView] = useState<View>("chats");
  const [chatOpen, setChatOpen] = useState(false);
  const [hidden, setHidden] = useState(false);

  const unread = db.msgs.filter((m) => m.to === me.username && !m.read).length;

  useEffect(() => {
    const t = setInterval(S.purgeExpired, 1000);
    const h = setInterval(() => S.touch(me.username), 30000);
    S.touch(me.username);
    return () => {
      clearInterval(t);
      clearInterval(h);
    };
  }, [me.username]);

  useEffect(() => {
    if (!me.prefs.blurOnBlur) return setHidden(false);
    const off = () => setHidden(true);
    const on = () => setHidden(false);
    window.addEventListener("blur", off);
    window.addEventListener("focus", on);
    return () => {
      window.removeEventListener("blur", off);
      window.removeEventListener("focus", on);
    };
  }, [me.prefs.blurOnBlur]);

  const nav = [
    { k: "chats" as const, icon: MessageSquare, label: "Chats", badge: unread },
    { k: "profile" as const, icon: UserRound, label: "Profil", badge: 0 },
    ...(me.role === "admin" ? [{ k: "admin" as const, icon: UserCog, label: "Admin", badge: 0 }] : []),
    { k: "settings" as const, icon: SettingsIcon, label: "Einstellungen", badge: 0 },
  ];

  return (
    <div className="h-dvh flex flex-col md:flex-row bg-bg">
      <nav className="hidden md:flex w-[60px] shrink-0 flex-col items-center py-3 gap-1 border-r border-line bg-surface">
        <div className="size-8 rounded-[3px] bg-accent grid place-items-center mb-4"><Lock size={15} className="text-bg" strokeWidth={2.5} /></div>
        {nav.map((n) => (
          <button key={n.k} title={n.label} aria-label={n.label} onClick={() => setView(n.k)} className={cx("relative size-10 grid place-items-center rounded-[3px] transition-colors", view === n.k ? "bg-raised text-accent" : "text-muted hover:text-fg hover:bg-raised")}>
            <n.icon size={18} />
            {n.badge > 0 && <span className="absolute top-1 right-1 min-w-4 h-4 px-1 rounded-full bg-accent text-bg text-[9.5px] font-mono font-semibold grid place-items-center">{n.badge}</span>}
          </button>
        ))}
        <div className="flex-1" />
        <button onClick={() => setView("profile")} aria-label="Mein Profil" className="mt-1"><Avatar name={me.name} size={30} src={me.avatar} /></button>
      </nav>

      <div className="flex-1 min-h-0 min-w-0 flex">
        {view === "chats" && <ChatsView onOpenChange={setChatOpen} />}
        {view === "profile" && <ProfileView />}
        {view === "admin" && me.role === "admin" && <Admin />}
        {view === "settings" && <Settings />}
      </div>

      <nav className={cx("md:hidden grid border-t border-line bg-surface", chatOpen && view === "chats" && "hidden")} style={{ gridTemplateColumns: `repeat(${nav.length + 1}, 1fr)` }}>
        {nav.map((n) => (
          <button key={n.k} onClick={() => setView(n.k)} className={cx("relative h-14 flex flex-col items-center justify-center gap-1 text-[10.5px]", view === n.k ? "text-accent" : "text-muted")}>
            <n.icon size={18} /> {n.label}
            {n.badge > 0 && <span className="absolute top-1.5 left-1/2 ml-2 min-w-4 h-4 px-1 rounded-full bg-accent text-bg text-[9.5px] font-mono font-semibold grid place-items-center">{n.badge}</span>}
          </button>
        ))}
      </nav>

      {hidden && (
        <button onClick={() => setHidden(false)} className="fixed inset-0 z-[90] bg-bg/60 backdrop-blur-2xl grid place-items-center text-muted">
          <span className="flex items-center gap-2 text-[14px]"><EyeOff size={16} /> Inhalte verborgen. Klicken zum Anzeigen.</span>
        </button>
      )}
    </div>
  );
}

function ChatsView({ onOpenChange }: { onOpenChange: (o: boolean) => void }) {
  const { me } = useSession();
  const db = S.useDB();
  const [active, setActive] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [addOpen, setAddOpen] = useState(false);

  useEffect(() => onOpenChange(!!active), [active, onOpenChange]);

  const rows = useMemo(() => {
    return db.convs
      .filter((c) => c.members.includes(me.username))
      .map((c) => {
        const partner = db.users.find((u) => u.username === c.members.find((m) => m !== me.username));
        const msgs = db.msgs.filter((m) => m.conv === c.id);
        const last = msgs[msgs.length - 1];
        return { c, partner, last, unread: msgs.filter((m) => m.to === me.username && !m.read).length };
      })
      .filter((r): r is typeof r & { partner: S.User } => !!r.partner && r.partner.status === "active")
      .filter((r) => !q || (r.partner.name + r.partner.username).toLowerCase().includes(q.toLowerCase()))
      .sort((a, b) => (b.last?.ts ?? b.c.created) - (a.last?.ts ?? a.c.created));
  }, [db, me.username, q]);

  const partner = db.users.find((u) => u.username === active);
  const activeOk = partner && partner.status === "active";

  return (
    <>
      <aside className={cx("w-full md:w-[320px] shrink-0 flex-col border-r border-line bg-surface min-h-0", active ? "hidden md:flex" : "flex")}>
        <header className="h-14 shrink-0 flex items-center justify-between px-4 border-b border-line">
          <div>
            <h1 className="text-[15px] font-semibold leading-none">Chats</h1>
            <div className="flex items-center gap-1 mt-1 font-mono text-[10px] text-accent uppercase tracking-wider"><Lock size={9} /> E2EE aktiv</div>
          </div>
          <Button size="sm" variant="ghost" onClick={() => setAddOpen(true)}><UserPlus size={14} /> Kontakt</Button>
        </header>
        <StoriesBar />
        <div className="p-3 border-b border-line">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
            <input className={cx(inputCls, "h-8 pl-8 text-[13px]")} placeholder="Suchen" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Chats durchsuchen" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {rows.map((r) => (
            <ConvItem key={r.c.id} partner={r.partner} last={r.last} unread={r.unread} ttl={r.c.ttl} active={active === r.partner.username} onClick={() => setActive(r.partner.username)} />
          ))}
          {rows.length === 0 && (
            <div className="p-6 text-[13px] text-faint leading-relaxed">
              Noch keine Chats. Füge einen Kontakt per QR-Code oder Kontaktcode hinzu.
              <Button size="sm" className="mt-3" onClick={() => setAddOpen(true)}><Plus size={13} /> Kontakt hinzufügen</Button>
            </div>
          )}
        </div>
      </aside>

      <section className={cx("flex-1 min-w-0 min-h-0", active ? "flex" : "hidden md:flex")}>
        {activeOk ? (
          <Chat key={partner.username} partner={partner} onBack={() => setActive(null)} onOpenUser={setActive} />
        ) : (
          <div className="flex-1 grid place-items-center grid-bg">
            <div className="text-center max-w-xs px-6">
              <div className="size-12 mx-auto mb-4 rounded-[3px] border border-line-strong grid place-items-center text-accent"><ShieldCheck size={22} /></div>
              <div className="text-[15px] font-medium">Wähle einen Chat</div>
              <p className="text-[13px] text-muted mt-1.5">Alle Nachrichten werden auf deinem Gerät ver- und entschlüsselt.</p>
            </div>
          </div>
        )}
      </section>

      <AddContact open={addOpen} onClose={() => setAddOpen(false)} onStart={(u) => { setActive(u); setAddOpen(false); }} />
    </>
  );
}

function ConvItem({ partner, last, unread, ttl, active, onClick }: { partner: S.User; last?: S.Msg; unread: number; ttl: number; active: boolean; onClick: () => void }) {
  const key = useConvKey(partner.pub);
  const get = useDecrypted(last ? [last] : [], key);
  const { me } = useSession();
  const raw = last && get(last.id);
  const preview = last ? (last.opened ? "Einmal-Foto geöffnet" : raw === undefined ? "…" : previewOf(decodePayload(raw))) : "Noch keine Nachrichten";
  return (
    <button onClick={onClick} className={cx("w-full text-left flex gap-3 px-4 py-3 border-b border-line transition-colors", active ? "bg-raised" : "hover:bg-raised/60")}>
      <Avatar name={partner.name} bot={partner.bot} src={partner.avatar} />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-[14px] font-medium truncate flex items-center gap-1.5">{partner.name}{ttl > 0 && <Timer size={11} className="text-warn shrink-0" />}</span>
          {last && <span className="font-mono text-[10.5px] text-faint shrink-0">{fmtTime(last.ts)}</span>}
        </div>
        <div className="flex items-center justify-between gap-2 mt-0.5">
          <span className={cx("text-[12.5px] truncate", unread ? "text-fg" : "text-muted")}>
            {last && last.from === me.username && "Du: "}{preview}
          </span>
          {unread > 0 && <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-accent text-bg text-[10px] font-mono font-semibold grid place-items-center shrink-0">{unread}</span>}
        </div>
      </div>
    </button>
  );
}

type Lightbox = { src: string; caption?: string; onceId?: string };

function Chat({ partner, onBack, onOpenUser }: { partner: S.User; onBack: () => void; onOpenUser: (u: string) => void }) {
  const { me } = useSession();
  const db = S.useDB();
  const toast = useToast();
  const key = useConvKey(partner.pub);
  const cid = S.convId(me.username, partner.username);
  const conv = db.convs.find((c) => c.id === cid);
  const msgs = useMemo(() => db.msgs.filter((m) => m.conv === cid), [db, cid]);
  const get = useDecrypted(msgs, key);
  const [text, setText] = useState("");
  const [raw, setRaw] = useState(false);
  const [safety, setSafety] = useState(false);
  const [profile, setProfile] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [draft, setDraft] = useState<{ img: string; caption: string; once: boolean } | null>(null);
  const [light, setLight] = useState<Lightbox | null>(null);
  const [reactFor, setReactFor] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  useTick(1000);

  const unreadCount = msgs.filter((m) => m.to === me.username && !m.read).length;
  useEffect(() => {
    if (unreadCount) S.markRead(cid, me.username, me.prefs.receipts);
  }, [unreadCount, cid, me.username, me.prefs.receipts]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs.length, key]);

  const items = useMemo(() => {
    const reactions = new Map<string, Map<string, string>>();
    const list: { m: S.Msg; p: Payload | null }[] = [];
    for (const m of msgs) {
      const t = get(m.id);
      const p = m.opened ? null : t === undefined ? undefined : decodePayload(t);
      if (p === undefined) continue;
      if (p?.t === "react") {
        const r = reactions.get(p.target) ?? new Map();
        if (p.emoji) r.set(m.from, p.emoji);
        else r.delete(m.from);
        reactions.set(p.target, r);
      } else list.push({ m, p });
    }
    return { list, reactions };
  }, [msgs, get]);

  async function transmit(p: Payload, once = false) {
    if (!key) return;
    try {
      const { iv, ct } = await C.encryptText(key, encodePayload(p));
      S.sendMsg(me.username, partner.username, iv, ct, once);
    } catch {
      toast("Speicher voll. Lösche alte Chats oder Fotos.", "error");
    }
  }
  function command(t: string) {
    const [cmd, arg = ""] = t.slice(1).trim().toLowerCase().split(/\s+/);
    const units: Record<string, number> = { s: 1, m: 60, h: 3600, d: 86400 };
    if (cmd === "clear") return setConfirmClear(true);
    if (cmd === "timer") {
      const m = /^(\d+)([smhd])$/.exec(arg);
      const sec = arg === "off" || arg === "aus" ? 0 : m ? +m[1] * units[m[2]] : NaN;
      if (Number.isNaN(sec)) return toast("Beispiel: /timer 24h, /timer 30m, /timer off", "error");
      S.setTtl(cid, sec);
      return toast(sec ? `Nachrichten verschwinden nach ${ttlLabel(sec)}` : "Timer aus", "info");
    }
    toast("Befehle: /clear (Verlauf für beide löschen) · /timer 24h|1h|30m|off (automatisch löschen)", "info");
  }
  async function send() {
    const t = text.trim();
    if (!t || !key) return;
    setText("");
    if (t.startsWith("/")) return command(t);
    await transmit({ t: "text", text: t });
  }
  async function react(target: string, emoji: string) {
    const mine = items.reactions.get(target)?.get(me.username);
    setReactFor(null);
    await transmit({ t: "react", target, emoji: mine === emoji ? "" : emoji });
  }
  async function pickPhoto(f?: File) {
    if (!f) return;
    try {
      setDraft({ img: await fileToDataUrl(f, 1000, 0.72), caption: "", once: false });
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }
  function closeLight() {
    if (light?.onceId) S.consumeOnce(light.onceId);
    setLight(null);
  }
  async function openCard(p: Extract<Payload, { t: "card" }>) {
    const u = await S.lookupUser(p.username);
    if (!u) return toast("Dieses Profil existiert nicht mehr.", "error");
    if (u.username === me.username) return;
    if ((await shortKey(u.pub)) !== p.k) return toast("Schlüssel passt nicht zur Profilkarte. Abgebrochen.", "error");
    S.startConv(me.username, u.username);
    onOpenUser(u.username);
  }

  const ttl = conv?.ttl ?? 0;
  const verified = isVerified(me.username, partner);
  const online = Date.now() - partner.lastSeen < 75000;
  const presence = partner.bot ? "Demo-Kontakt" : partner.prefs.showSeen === false ? "" : online ? "online" : `zuletzt aktiv ${fmtRel(partner.lastSeen)}`;

  return (
    <div className="flex-1 min-w-0 flex flex-col min-h-0">
      <header className="h-14 shrink-0 flex items-center gap-3 px-3 sm:px-4 border-b border-line bg-surface">
        <button onClick={onBack} aria-label="Zurück" className="md:hidden text-muted hover:text-fg p-1"><ArrowLeft size={18} /></button>
        <button onClick={() => setProfile(true)} className="flex items-center gap-3 min-w-0 flex-1 text-left" aria-label="Profil anzeigen">
          <Avatar name={partner.name} size={32} bot={partner.bot} src={partner.avatar} />
          <div className="min-w-0">
            <div className="text-[14px] font-semibold truncate leading-tight flex items-center gap-1.5">{partner.name}{verified && <ShieldCheck size={13} className="text-accent shrink-0" />}</div>
            <div className="font-mono text-[10.5px] text-muted truncate flex items-center gap-1.5">
              @{partner.username}{presence && <> · {online && !partner.bot && <span className="size-1.5 rounded-full bg-accent" />}{presence}</>}
            </div>
          </div>
        </button>
        <div className="flex items-center gap-1">
          <label className="relative flex items-center gap-1.5 h-8 pl-2 pr-1 rounded-[3px] border border-line-strong text-[12px] text-muted hover:text-fg" title="Verschwindende Nachrichten">
            <Timer size={13} className={ttl ? "text-warn" : ""} />
            <select aria-label="Timer für verschwindende Nachrichten" value={ttl} onChange={(e) => { S.setTtl(cid, +e.target.value); toast(+e.target.value ? `Nachrichten verschwinden nach ${ttlLabel(+e.target.value)}` : "Timer deaktiviert", "info"); }} className="bg-transparent text-[12px] outline-none pr-1 text-fg w-[4.2rem]">
              {TTLS.map(([v, l]) => <option key={v} value={v} className="bg-surface">{l}</option>)}
            </select>
          </label>
          <Button variant={raw ? "primary" : "ghost"} size="sm" onClick={() => setRaw(!raw)} title="Zeigt, was der Server speichert"><Server size={13} /><span className="hidden lg:inline">Server-Ansicht</span></Button>
          <Button variant="ghost" size="sm" onClick={() => setSafety(true)} title="Sicherheitsnummer" aria-label="Sicherheitsnummer"><Fingerprint size={13} /></Button>
          <Button variant="ghost" size="sm" onClick={() => setConfirmClear(true)} title="Verlauf löschen" aria-label="Verlauf löschen"><Trash2 size={13} /></Button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-3 sm:px-6 py-5 grid-bg">
        <div className="max-w-2xl mx-auto flex flex-col gap-1">
          <div className="mx-auto mb-4 max-w-sm text-center text-[11.5px] leading-relaxed text-muted bg-surface/90 border border-line rounded-[3px] px-4 py-3">
            <Lock size={12} className="inline mr-1.5 text-accent -mt-0.5" />
            Nachrichten, Fotos und Stories sind Ende-zu-Ende verschlüsselt. Nicht einmal Administratoren können sie lesen.
          </div>
          {items.list.map(({ m, p }, i) => {
            const mine = m.from === me.username;
            const prev = items.list[i - 1]?.m;
            const newDay = !prev || new Date(prev.ts).toDateString() !== new Date(m.ts).toDateString();
            const remain = m.exp ? Math.max(0, Math.ceil((m.exp - Date.now()) / 1000)) : null;
            const rs = items.reactions.get(m.id);
            const counts = new Map<string, number>();
            rs?.forEach((e) => counts.set(e, (counts.get(e) ?? 0) + 1));
            const bubble = cx("rounded-[4px] text-[14px] leading-snug break-words", mine ? "bg-accent text-bg rounded-br-[1px]" : "bg-raised border border-line text-fg rounded-bl-[1px]");
            return (
              <Fragment key={m.id}>
                {newDay && <div className="self-center my-3 font-mono text-[10.5px] uppercase tracking-[0.12em] text-faint">{fmtDay(m.ts)}</div>}
                <div className={cx("group max-w-[82%] animate-rise", mine ? "self-end" : "self-start", prev && prev.from !== m.from && "mt-2")}>
                  <div className={cx("flex items-center gap-1.5", mine && "flex-row-reverse")}>
                    <div className={cx(bubble, p?.t === "img" && !p.once ? "p-1" : "px-3 py-2", "whitespace-pre-wrap min-w-0")}>
                      {m.opened ? (
                        <span className="flex items-center gap-1.5 opacity-70 italic"><Flame size={13} /> Einmal-Foto geöffnet</span>
                      ) : p?.t === "text" ? (
                        p.text
                      ) : p?.t === "img" && p.once ? (
                        mine ? (
                          <span className="flex items-center gap-1.5"><Flame size={13} /> Einmal-Foto gesendet</span>
                        ) : (
                          <button onClick={() => setLight({ src: p.img, caption: p.caption, onceId: m.id })} className="flex items-center gap-2 font-medium"><Flame size={14} className="text-warn" /> Einmal ansehen</button>
                        )
                      ) : p?.t === "img" ? (
                        <button onClick={() => setLight({ src: p.img, caption: p.caption })} className="block">
                          <img src={p.img} alt={p.caption ?? "Foto"} className="rounded-[3px] max-h-64 max-w-full object-cover" />
                          {p.caption && <div className="px-2 pt-1.5 pb-1 text-left whitespace-pre-wrap">{p.caption}</div>}
                        </button>
                      ) : p?.t === "card" ? (
                        <div className="w-60 whitespace-normal">
                          <div className="flex items-center gap-3">
                            <Avatar name={p.name} src={p.avatar} size={40} />
                            <div className="min-w-0"><div className="font-semibold truncate">{p.name}</div><div className="font-mono text-[11px] opacity-70 truncate">@{p.username}</div></div>
                          </div>
                          {p.bio && <div className="text-[12.5px] opacity-80 mt-2">{p.bio}</div>}
                          <button onClick={() => openCard(p)} disabled={p.username === me.username} className={cx("mt-3 w-full h-8 rounded-[3px] text-[12.5px] font-medium border disabled:opacity-40", mine ? "border-bg/40 hover:bg-bg/10" : "border-line-strong hover:bg-surface")}>{p.username === me.username ? "Dein Profil" : "Chat öffnen"}</button>
                        </div>
                      ) : null}
                    </div>
                    <button onClick={() => setReactFor(reactFor === m.id ? null : m.id)} aria-label="Reagieren" className="opacity-0 group-hover:opacity-100 focus-visible:opacity-100 text-faint hover:text-fg shrink-0 p-1"><SmilePlus size={15} /></button>
                  </div>
                  {reactFor === m.id && (
                    <div className={cx("flex gap-0.5 mt-1 p-1 bg-raised border border-line-strong rounded-full w-fit animate-rise", mine && "ml-auto")}>
                      {EMOJIS.map((e) => <button key={e} onClick={() => react(m.id, e)} className="size-8 rounded-full hover:bg-surface text-[17px]">{e}</button>)}
                    </div>
                  )}
                  {counts.size > 0 && (
                    <div className={cx("flex gap-1 mt-1", mine && "justify-end")}>
                      {[...counts].map(([e, n]) => (
                        <button key={e} onClick={() => react(m.id, e)} className={cx("h-5 px-1.5 rounded-full border text-[12px] flex items-center gap-1", rs?.get(me.username) === e ? "border-accent/60 bg-accent/10" : "border-line-strong bg-surface")}>{e}{n > 1 && <span className="font-mono text-[10px] text-muted">{n}</span>}</button>
                      ))}
                    </div>
                  )}
                  {raw && <div className="mt-1 font-mono text-[10px] text-faint break-all leading-tight max-w-[22rem]">iv:{m.iv} <br />ct:{m.ct.slice(0, 96)}{m.ct.length > 96 && "…"}</div>}
                  <div className={cx("mt-1 flex items-center gap-1.5 font-mono text-[10px] text-faint", mine && "justify-end")}>
                    {remain !== null && <span className="flex items-center gap-0.5 text-warn"><Hourglass size={9} />{remain >= 3600 ? `${Math.floor(remain / 3600)}h` : remain >= 60 ? `${Math.floor(remain / 60)}m` : `${remain}s`}</span>}
                    {fmtTime(m.ts)}
                    {mine && (m.read && m.rr ? <CheckCheck size={12} className="text-accent" /> : <Check size={12} />)}
                  </div>
                </div>
              </Fragment>
            );
          })}
          <div ref={endRef} />
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="shrink-0 border-t border-line bg-surface p-3">
        <div className="max-w-2xl mx-auto flex items-end gap-2">
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { pickPhoto(e.target.files?.[0]); e.target.value = ""; }} />
          <Button type="button" variant="ghost" size="lg" className="w-11 !px-0" onClick={() => fileRef.current?.click()} aria-label="Foto senden"><ImagePlus size={16} /></Button>
          <textarea
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Verschlüsselte Nachricht"
            aria-label="Nachricht"
            className="flex-1 resize-none max-h-32 min-h-11 rounded-[3px] bg-bg border border-line-strong px-3 py-2.5 text-[14px] placeholder:text-faint focus:border-accent focus:outline-none"
          />
          <Button type="submit" size="lg" className="w-11 !px-0" disabled={!text.trim() || !key} aria-label="Senden"><Send size={16} /></Button>
        </div>
      </form>

      <Modal open={!!draft} onClose={() => setDraft(null)} title="Foto senden">
        {draft && (
          <div className="space-y-3">
            <img src={draft.img} alt="Vorschau" className="w-full max-h-72 object-contain rounded-[3px] bg-bg" />
            <input value={draft.caption} onChange={(e) => setDraft({ ...draft, caption: e.target.value })} placeholder="Bildunterschrift (optional)" className={inputCls} />
            <div className="flex items-center justify-between gap-4 py-1">
              <div><div className="text-[13.5px] flex items-center gap-1.5"><Flame size={13} className="text-warn" /> Nur einmal ansehen</div><div className="text-[12px] text-muted">Das Foto wird nach dem Öffnen für beide gelöscht.</div></div>
              <Toggle label="Einmal ansehen" on={draft.once} onChange={(v) => setDraft({ ...draft, once: v })} />
            </div>
            <Button className="w-full" onClick={async () => { await transmit({ t: "img", img: draft.img, caption: draft.caption.trim() || undefined, once: draft.once || undefined }, draft.once); setDraft(null); }}><Send size={14} /> Senden</Button>
          </div>
        )}
      </Modal>

      {light && (
        <div className="fixed inset-0 z-[80] bg-black/95 grid place-items-center p-4" onClick={closeLight}>
          <div className="max-w-3xl max-h-full flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
            {light.onceId && <Chip tone="warn"><Flame size={10} /> Einmal-Ansicht · wird beim Schließen gelöscht</Chip>}
            <img src={light.src} alt="" className="max-h-[78dvh] max-w-full object-contain rounded-[3px]" />
            {light.caption && <div className="text-[14px]">{light.caption}</div>}
            <Button variant="ghost" onClick={closeLight}>Schließen</Button>
          </div>
        </div>
      )}

      <PartnerProfile open={profile} onClose={() => setProfile(false)} partner={partner} onSafety={() => { setProfile(false); setSafety(true); }} />
      <SafetyModal open={safety} onClose={() => setSafety(false)} partner={partner} />
      <Modal open={confirmClear} onClose={() => setConfirmClear(false)} title="Verlauf löschen?">
        <p className="text-[13.5px] text-muted mb-4">Alle Nachrichten dieses Chats werden für beide Seiten entfernt. Das lässt sich nicht rückgängig machen.</p>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={() => setConfirmClear(false)}>Abbrechen</Button>
          <Button variant="danger" onClick={() => { S.clearConv(cid); setConfirmClear(false); toast("Verlauf gelöscht"); }}>Löschen</Button>
        </div>
      </Modal>
    </div>
  );
}

function PartnerProfile({ open, onClose, partner, onSafety }: { open: boolean; onClose: () => void; partner: S.User; onSafety: () => void }) {
  const { me } = useSession();
  const verified = isVerified(me.username, partner);
  return (
    <Modal open={open} onClose={onClose} title="Profil">
      <div className="flex flex-col items-center text-center">
        <Avatar name={partner.name} size={96} bot={partner.bot} src={partner.avatar} />
        <h3 className="text-[20px] font-semibold tracking-tight mt-4 flex items-center gap-2">{partner.name}{verified && <ShieldCheck size={16} className="text-accent" />}</h3>
        <div className="font-mono text-[12px] text-muted">@{partner.username}</div>
        {partner.mood && <div className="mt-3"><Chip tone="accent">{partner.mood}</Chip></div>}
        {partner.bio && <p className="text-[13.5px] text-muted mt-4 max-w-xs leading-relaxed">{partner.bio}</p>}
        <div className="font-mono text-[11px] text-faint mt-4">Dabei seit {new Date(partner.created).toLocaleDateString("de-DE", { month: "long", year: "numeric" })}</div>
        <Button variant="ghost" className="mt-5 w-full" onClick={onSafety}><Fingerprint size={14} /> {verified ? "Sicherheitsnummer ansehen" : "Identität verifizieren"}</Button>
      </div>
    </Modal>
  );
}

function SafetyModal({ open, onClose, partner }: { open: boolean; onClose: () => void; partner: S.User }) {
  const { me } = useSession();
  const [nums, setNums] = useState<string[]>([]);
  const [verified, setV] = useState(() => isVerified(me.username, partner));
  useEffect(() => {
    if (open) {
      C.safetyNumber(me.pub, partner.pub).then(setNums);
      setV(isVerified(me.username, partner));
    }
  }, [open, me.pub, me.username, partner]);
  return (
    <Modal open={open} onClose={onClose} title={`Sicherheitsnummer · ${partner.name}`}>
      <p className="text-[13px] text-muted mb-4 leading-relaxed">Vergleiche diese Zahlen persönlich oder über einen anderen Kanal. Stimmen sie überein, liest niemand mit. Wer deinen QR-Code scannt, ist automatisch verifiziert.</p>
      <div className="grid grid-cols-4 gap-px bg-line border border-line font-mono text-[15px] mb-4">
        {nums.map((n, i) => <div key={i} className="bg-bg py-2.5 text-center tracking-wider">{n}</div>)}
      </div>
      <div className="flex items-center justify-between">
        {verified ? <Chip tone="accent"><ShieldCheck size={11} /> Verifiziert</Chip> : <Chip>Nicht verifiziert</Chip>}
        <Button variant={verified ? "ghost" : "primary"} size="sm" onClick={() => { setVerified(me.username, partner, !verified); setV(!verified); }}>{verified ? "Markierung entfernen" : "Als verifiziert markieren"}</Button>
      </div>
    </Modal>
  );
}

function Row({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-6 py-3.5 border-b border-line last:border-0">
      <div className="min-w-0">
        <div className="text-[14px]">{title}</div>
        {desc && <div className="text-[12.5px] text-muted mt-0.5 leading-snug">{desc}</div>}
      </div>
      {children}
    </div>
  );
}

function Settings() {
  const { me, logout } = useSession();
  const toast = useToast();
  const [fp, setFp] = useState<string[]>([]);
  const [del, setDel] = useState(false);
  const [pairOpen, setPairOpen] = useState(false);
  useEffect(() => { C.fingerprint(me.pub).then(setFp); }, [me.pub]);

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-2xl mx-auto px-5 py-8 space-y-9">
        <h1 className="text-[22px] font-semibold tracking-tight">Einstellungen</h1>

        <section>
          <Label className="mb-2">Identitätsschlüssel</Label>
          <div className="border border-line-strong rounded-[3px] p-4 bg-surface">
            <div className="grid grid-cols-4 gap-x-4 gap-y-1 font-mono text-[14px]">{fp.map((g, i) => <span key={i}>{g}</span>)}</div>
            <p className="text-[12px] text-faint mt-3 leading-relaxed">Fingerabdruck deines öffentlichen ECDH-P-256-Schlüssels. Dein privater Schlüssel verlässt den Browser nur verschlüsselt.</p>
          </div>
        </section>

        <section>
          <Label className="mb-1">Privatsphäre</Label>
          <Row title="Lesebestätigungen" desc="Andere sehen, wann du Nachrichten gelesen hast."><Toggle label="Lesebestätigungen" on={me.prefs.receipts} onChange={(v) => S.updatePrefs(me.username, { receipts: v })} /></Row>
          <Row title="Online-Status anzeigen" desc="Kontakte sehen, ob du online bist und wann du zuletzt aktiv warst."><Toggle label="Online-Status" on={me.prefs.showSeen !== false} onChange={(v) => S.updatePrefs(me.username, { showSeen: v })} /></Row>
          <Row title="Inhalte bei Fokusverlust verbergen" desc="Weichzeichnen, sobald du den Tab verlässt."><Toggle label="Inhalte verbergen" on={me.prefs.blurOnBlur} onChange={(v) => S.updatePrefs(me.username, { blurOnBlur: v })} /></Row>
        </section>

        <section>
          <Label className="mb-2">Weiteres Gerät</Label>
          <p className="text-[12.5px] text-muted mb-3 leading-relaxed">Übernimm dein Konto samt Chat auf ein anderes Gerät. Der Schlüssel wird mit einer PIN verschlüsselt direkt übertragen, nicht über den Server.</p>
          <Button variant="ghost" onClick={() => setPairOpen(true)}>Gerät koppeln</Button>
          <PairShow open={pairOpen} onClose={() => setPairOpen(false)} />
        </section>

        <section className="border-t border-line pt-6 flex flex-wrap gap-3">
          <Button variant="ghost" onClick={() => logout()}><LogOut size={14} /> Abmelden</Button>
          <Button variant="danger" onClick={() => setDel(true)}><Trash2 size={14} /> Konto löschen</Button>
        </section>
      </div>

      <Modal open={del} onClose={() => setDel(false)} title="Konto endgültig löschen?">
        <p className="text-[13.5px] text-muted mb-4">Dein Konto, dein Schlüsselpaar und alle deine Chats werden entfernt. Das ist nicht umkehrbar.</p>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={() => setDel(false)}>Abbrechen</Button>
          <Button variant="danger" onClick={() => { S.deleteSelf(me.username); }}>Endgültig löschen</Button>
        </div>
      </Modal>
    </div>
  );
}
