import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { Check, Info, AlertTriangle, X } from "lucide-react";
import QRCode from "qrcode";

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");

export const fmtTime = (ts: number) => new Date(ts).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
export const fmtDate = (ts: number) => new Date(ts).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "2-digit" });
export const fmtStamp = (ts: number) => `${fmtDate(ts)} ${fmtTime(ts)}`;
export function fmtDay(ts: number) {
  const d = new Date(ts);
  const t = new Date();
  const y = new Date(Date.now() - 86400000);
  if (d.toDateString() === t.toDateString()) return "Heute";
  if (d.toDateString() === y.toDateString()) return "Gestern";
  return d.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
}
export function fmtRel(ts: number) {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return "gerade eben";
  if (s < 3600) return `vor ${Math.floor(s / 60)} Min.`;
  if (s < 86400) return `vor ${Math.floor(s / 3600)} Std.`;
  return `vor ${Math.floor(s / 86400)} Tg.`;
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "quiet"; size?: "sm" | "md" | "lg" };
export function Button({ variant = "primary", size = "md", className, ...p }: BtnProps) {
  return (
    <button
      {...p}
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-[3px] font-medium transition-colors disabled:opacity-40 disabled:pointer-events-none whitespace-nowrap",
        size === "sm" && "h-7 px-2.5 text-[12px]",
        size === "md" && "h-9 px-3.5 text-[13px]",
        size === "lg" && "h-11 px-5 text-[14px]",
        variant === "primary" && "bg-accent text-bg hover:bg-[#d6ff6e]",
        variant === "ghost" && "border border-line-strong text-fg hover:bg-raised",
        variant === "danger" && "border border-danger/40 text-danger hover:bg-danger/10",
        variant === "quiet" && "text-muted hover:text-fg hover:bg-raised",
        className,
      )}
    />
  );
}

export const inputCls =
  "w-full h-10 rounded-[3px] bg-surface border border-line-strong px-3 text-[14px] text-fg placeholder:text-faint focus:border-accent focus:outline-none transition-colors";

export function Field({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <label className="block">
      <span className="flex items-baseline justify-between mb-1.5">
        <span className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-muted">{label}</span>
        {hint && <span className="text-[11px] text-faint">{hint}</span>}
      </span>
      {children}
    </label>
  );
}

export function Label({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx("font-mono text-[10.5px] uppercase tracking-[0.12em] text-faint", className)}>{children}</div>;
}

export function Chip({ tone = "neutral", children }: { tone?: "neutral" | "accent" | "danger" | "warn"; children: ReactNode }) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 h-5 px-1.5 rounded-[2px] font-mono text-[10.5px] uppercase tracking-wider border",
        tone === "neutral" && "border-line-strong text-muted",
        tone === "accent" && "border-accent/40 text-accent bg-accent/10",
        tone === "danger" && "border-danger/40 text-danger bg-danger/10",
        tone === "warn" && "border-warn/40 text-warn bg-warn/10",
      )}
    >
      {children}
    </span>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cx("relative w-9 h-5 rounded-full border transition-colors shrink-0", on ? "bg-accent border-accent" : "bg-surface border-line-strong")}
    >
      <span className={cx("absolute top-0.5 size-3.5 rounded-full transition-all", on ? "left-[18px] bg-bg" : "left-0.5 bg-muted")} />
    </button>
  );
}

export function Avatar({ name, size = 36, bot, src }: { name: string; size?: number; bot?: boolean; src?: string }) {
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) % 360;
  const initials = name.trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  if (src) return <img src={src} alt="" width={size} height={size} className="shrink-0 rounded-[3px] object-cover select-none" style={{ width: size, height: size }} />;
  return (
    <div
      className="shrink-0 grid place-items-center rounded-[3px] font-mono font-semibold select-none"
      style={{
        width: size, height: size, fontSize: size * 0.34,
        background: bot ? "var(--color-accent)" : `oklch(0.3 0.05 ${h})`,
        color: bot ? "var(--color-bg)" : `oklch(0.86 0.09 ${h})`,
      }}
    >
      {initials || "?"}
    </div>
  );
}

export function Modal({ open, onClose, title, children, width = "max-w-md" }: { open: boolean; onClose: () => void; title: string; children: ReactNode; width?: string }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/70 backdrop-blur-sm animate-rise" onMouseDown={onClose}>
      <div role="dialog" aria-label={title} onMouseDown={(e) => e.stopPropagation()} className={cx("w-full bg-surface border border-line-strong rounded-[4px] shadow-2xl", width)}>
        <div className="flex items-center justify-between h-12 px-4 border-b border-line">
          <h2 className="text-[14px] font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Schließen" className="text-muted hover:text-fg">
            <X size={16} />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

type ToastTone = "ok" | "info" | "error";
const ToastCtx = createContext<(msg: string, tone?: ToastTone) => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<{ id: number; msg: string; tone: ToastTone }[]>([]);
  const push = useCallback((msg: string, tone: ToastTone = "ok") => {
    const id = Math.random();
    setItems((x) => [...x, { id, msg, tone }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), 3600);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 right-4 z-[60] flex flex-col gap-2 pointer-events-none">
        {items.map((t) => (
          <div key={t.id} className="animate-rise pointer-events-auto flex items-center gap-2 bg-raised border border-line-strong rounded-[3px] pl-3 pr-4 h-10 text-[13px] shadow-xl">
            {t.tone === "ok" && <Check size={14} className="text-accent" />}
            {t.tone === "info" && <Info size={14} className="text-muted" />}
            {t.tone === "error" && <AlertTriangle size={14} className="text-danger" />}
            {t.msg}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function QR({ value, size = 220 }: { value: string; size?: number }) {
  const { n, path } = useMemo(() => {
    const q = QRCode.create(value, { errorCorrectionLevel: "M" });
    const n = q.modules.size;
    let d = "";
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (q.modules.data[y * n + x]) d += `M${x + 4} ${y + 4}h1v1h-1z`;
    return { n, path: d };
  }, [value]);
  return (
    <svg role="img" aria-label="QR-Code" width={size} height={size} viewBox={`0 0 ${n + 8} ${n + 8}`} shapeRendering="crispEdges" className="rounded-[3px] bg-white">
      <path d={path} fill="#0a0b0c" />
    </svg>
  );
}
