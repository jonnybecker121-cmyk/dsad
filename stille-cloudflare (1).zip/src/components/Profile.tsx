import { useRef, useState } from "react";
import { Camera, Copy, Link2, Send, Share2, Trash2 } from "lucide-react";
import * as C from "../lib/crypto";
import { useContactCode, shortKey } from "../lib/contact";
import { fileToDataUrl } from "../lib/image";
import { encodePayload } from "../lib/payload";
import * as S from "../lib/server";
import { useSession } from "../lib/session";
import { Avatar, Button, Chip, Field, Label, Modal, QR, cx, inputCls, useToast } from "./ui";

const MOODS = ["Verfügbar", "Beschäftigt", "In einer Besprechung", "Unterwegs", "Bitte nicht stören", "Nur Notfälle"];

export function useContacts() {
  const db = S.useDB();
  const { me } = useSession();
  return db.convs
    .filter((c) => c.members.includes(me.username))
    .map((c) => db.users.find((u) => u.username === c.members.find((m) => m !== me.username)))
    .filter((u): u is S.User => !!u && u.status === "active" && !u.bot);
}

export async function sendCard(me: S.User, priv: CryptoKey, to: S.User) {
  const key = await C.convKey(priv, to.pub);
  const k = await shortKey(me.pub);
  const { iv, ct } = await C.encryptText(key, encodePayload({ t: "card", username: me.username, name: me.name, bio: me.bio, avatar: me.avatar, k }));
  S.sendMsg(me.username, to.username, iv, ct);
}

export function MyCode({ size = 200, compact }: { size?: number; compact?: boolean }) {
  const { me } = useSession();
  const code = useContactCode(me);
  const toast = useToast();
  if (!code) return null;
  const copy = (t: string, m: string) => navigator.clipboard?.writeText(t).then(() => toast(m), () => toast("Kopieren nicht möglich", "error"));
  const share = async () => {
    const text = `Schreib mir auf Stille: ${code}`;
    if (navigator.share) await navigator.share({ title: "Mein Stille-Kontakt", text }).catch(() => {});
    else copy(text, "Einladungstext kopiert");
  };
  return (
    <div className={cx("flex gap-5 items-center", compact ? "flex-col" : "flex-col sm:flex-row")}>
      <div className="p-2 bg-white rounded-[4px] shrink-0"><QR value={code} size={size} /></div>
      <div className="min-w-0 w-full">
        <Label className="mb-1.5">Kontaktcode</Label>
        <div className="font-mono text-[12.5px] break-all border border-line-strong bg-bg rounded-[3px] px-3 py-2.5 select-all">{code}</div>
        <p className="text-[12px] text-faint mt-2 leading-relaxed">Wer diesen Code scannt oder einfügt, findet dich und prüft gleichzeitig deinen Schlüssel.</p>
        <div className="flex flex-wrap gap-2 mt-3">
          <Button size="sm" variant="ghost" onClick={() => copy(code, "Code kopiert")}><Copy size={12} /> Code</Button>
          <Button size="sm" variant="ghost" onClick={() => copy(`@${me.username}`, "Benutzername kopiert")}><Link2 size={12} /> @{me.username}</Button>
          <Button size="sm" variant="ghost" onClick={share}><Share2 size={12} /> Teilen</Button>
        </div>
      </div>
    </div>
  );
}

export default function ProfileView() {
  const { me, priv } = useSession();
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState(me.name);
  const [bio, setBio] = useState(me.bio ?? "");
  const [shareOpen, setShareOpen] = useState(false);
  const contacts = useContacts();
  const dirty = name.trim() !== me.name || bio !== (me.bio ?? "");

  async function pickAvatar(f?: File) {
    if (!f) return;
    try {
      S.updateProfile(me.username, { avatar: await fileToDataUrl(f, 192, 0.8, true) });
      toast("Profilbild aktualisiert");
    } catch (e) {
      toast((e as Error).message, "error");
    }
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-5 py-8 space-y-9">
        <header className="flex items-center gap-5">
          <div className="relative group">
            <Avatar name={me.name} size={96} src={me.avatar} />
            <button onClick={() => fileRef.current?.click()} aria-label="Profilbild ändern" className="absolute inset-0 rounded-[3px] bg-black/60 grid place-items-center opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity"><Camera size={20} /></button>
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { pickAvatar(e.target.files?.[0]); e.target.value = ""; }} />
          </div>
          <div className="min-w-0">
            <h1 className="text-[24px] font-semibold tracking-tight truncate">{me.name}</h1>
            <div className="font-mono text-[12px] text-muted flex items-center gap-2 mt-0.5">@{me.username} {me.role === "admin" && <Chip tone="accent">Admin</Chip>}</div>
            <div className="flex gap-2 mt-3">
              <Button size="sm" variant="ghost" onClick={() => fileRef.current?.click()}><Camera size={12} /> Bild wählen</Button>
              {me.avatar && <Button size="sm" variant="quiet" onClick={() => S.updateProfile(me.username, { avatar: null })}><Trash2 size={12} /> Entfernen</Button>}
            </div>
          </div>
        </header>

        <section>
          <Label className="mb-3">Profil</Label>
          <form onSubmit={(e) => { e.preventDefault(); S.updateProfile(me.username, { name, bio }); toast("Profil gespeichert"); }} className="space-y-4">
            <Field label="Anzeigename"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} maxLength={40} /></Field>
            <Field label="Über mich" hint={`${bio.length}/140`}>
              <textarea className={cx(inputCls, "h-20 py-2 resize-none")} value={bio} onChange={(e) => setBio(e.target.value.slice(0, 140))} placeholder="Ein Satz, den deine Kontakte sehen." />
            </Field>
            <Button type="submit" disabled={!dirty || !name.trim()}>Speichern</Button>
          </form>
        </section>

        <section>
          <Label className="mb-3">Status</Label>
          <div className="flex flex-wrap gap-2">
            {MOODS.map((m) => (
              <button key={m} onClick={() => S.updateProfile(me.username, { mood: me.mood === m ? "" : m })} className={cx("h-8 px-3 rounded-[3px] border text-[13px] transition-colors", me.mood === m ? "border-accent bg-accent/10 text-accent" : "border-line-strong text-muted hover:text-fg hover:bg-raised")}>{m}</button>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-3">
            <Label>Mein Kontaktcode</Label>
            <Button size="sm" variant="ghost" onClick={() => setShareOpen(true)} disabled={!contacts.length}><Send size={12} /> Profil in Chat senden</Button>
          </div>
          <div className="border border-line-strong rounded-[3px] bg-surface p-5"><MyCode /></div>
        </section>
      </div>

      <Modal open={shareOpen} onClose={() => setShareOpen(false)} title="Profil senden an …">
        <div className="-mx-4 -mb-4 max-h-80 overflow-y-auto">
          {contacts.map((u) => (
            <button key={u.username} onClick={async () => { await sendCard(me, priv, u); setShareOpen(false); toast(`Profil an ${u.name} gesendet`); }} className="w-full flex items-center gap-3 px-4 py-2.5 border-t border-line hover:bg-raised text-left">
              <Avatar name={u.name} size={32} src={u.avatar} />
              <div><div className="text-[13.5px]">{u.name}</div><div className="font-mono text-[11px] text-muted">@{u.username}</div></div>
            </button>
          ))}
        </div>
      </Modal>
    </div>
  );
}
