import { useEffect, useState } from "react";
import { ArrowRight, Smartphone } from "lucide-react";
import * as S from "../lib/server";
import { Scanner } from "./AddContact";
import { Button, Field, Modal, QR, inputCls } from "./ui";

const fmtPin = (p: string) => p.replace(/(\d{5})(\d{5})/, "$1 $2");

/** Auf dem bereits angemeldeten Gerät: zeigt QR + PIN für ein neues Gerät. */
export function PairShow({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [d, setD] = useState<{ code: string; pin: string } | null>(null);
  const [err, setErr] = useState("");
  const [left, setLeft] = useState(120);
  useEffect(() => {
    if (!open) return;
    setD(null);
    setErr("");
    setLeft(120);
    S.exportPairing().then(setD).catch((e) => setErr(e.message));
  }, [open]);
  useEffect(() => {
    if (!open || !d) return;
    const t = setInterval(() => setLeft((x) => x - 1), 1000);
    return () => clearInterval(t);
  }, [open, d]);
  useEffect(() => {
    if (left <= 0) {
      setD(null);
      onClose();
    }
  }, [left, onClose]);
  return (
    <Modal open={open} onClose={onClose} title="Neues Gerät koppeln">
      {err && <div className="text-[13px] text-danger">{err}</div>}
      {d && (
        <div className="space-y-4 text-center">
          <div className="grid place-items-center"><QR value={d.code} size={220} /></div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-faint font-mono">PIN</div>
            <div className="font-mono text-[22px] tracking-[0.15em]">{fmtPin(d.pin)}</div>
          </div>
          <p className="text-[12px] text-muted leading-relaxed">Scanne den Code mit dem neuen Gerät (Anmeldeseite → „Gerät koppeln“) und gib die PIN ein. Zeige beides niemand anderem. Schließt sich in {left} s.</p>
          <Button variant="ghost" className="w-full" onClick={() => navigator.clipboard?.writeText(d.code)}>Code als Text kopieren</Button>
        </div>
      )}
    </Modal>
  );
}

/** Auf dem neuen Gerät: QR scannen oder Text einfügen, PIN eingeben. */
export function PairJoin({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: (r: S.LoginResult) => void }) {
  const [code, setCode] = useState("");
  const [pin, setPin] = useState("");
  const [scan, setScan] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setErr("");
    setBusy(true);
    try {
      onDone(await S.importPairing(code, pin));
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  }
  return (
    <Modal open={open} onClose={onClose} title="Gerät koppeln">
      <div className="space-y-4">
        {scan ? (
          <Scanner onCode={(c) => { setCode(c); setScan(false); }} />
        ) : (
          <>
            <Field label="Kopplungscode" hint="QR scannen oder Text einfügen">
              <input className={inputCls} value={code} onChange={(e) => setCode(e.target.value)} placeholder="stille://pair/…" spellCheck={false} autoCapitalize="none" />
            </Field>
            <Button variant="ghost" className="w-full" onClick={() => setScan(true)}><Smartphone size={14} /> QR-Code scannen</Button>
            <Field label="PIN (10 Ziffern)"><input className={inputCls} inputMode="numeric" value={pin} onChange={(e) => setPin(e.target.value)} placeholder="12345 67890" /></Field>
            {err && <div role="alert" className="text-[13px] text-danger">{err}</div>}
            <Button className="w-full" disabled={busy || !code || pin.replace(/\D/g, "").length !== 10} onClick={go}>Koppeln <ArrowRight size={15} /></Button>
          </>
        )}
      </div>
    </Modal>
  );
}
