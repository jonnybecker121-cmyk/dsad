import { useEffect, useRef, useState } from "react";
import { Camera, ImageUp, ScanLine } from "lucide-react";
import jsQR from "jsqr";
import { addContact } from "../lib/contact";
import { useSession } from "../lib/session";
import { Button, Field, Modal, cx, inputCls, useToast } from "./ui";
import { MyCode } from "./Profile";

export function Scanner({ onCode }: { onCode: (s: string) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const file = useRef<HTMLInputElement>(null);
  const [err, setErr] = useState("");
  const done = useRef(false);
  const cb = useRef(onCode);
  cb.current = onCode;

  useEffect(() => {
    let stream: MediaStream | undefined;
    let raf = 0;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
    let last = 0;
    const tick = (t: number) => {
      const v = video.current;
      if (v && v.readyState >= 2 && t - last > 120 && !done.current) {
        last = t;
        canvas.width = v.videoWidth;
        canvas.height = v.videoHeight;
        ctx.drawImage(v, 0, 0);
        const r = jsQR(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height);
        if (r?.data) {
          done.current = true;
          cb.current(r.data);
        }
      }
      raf = requestAnimationFrame(tick);
    };
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: "environment" } })
      .then((s) => {
        stream = s;
        if (video.current) {
          video.current.srcObject = s;
          video.current.play();
        }
        raf = requestAnimationFrame(tick);
      })
      .catch(() => setErr("Kein Kamerazugriff. Erlaube die Kamera oder lade ein Bild mit dem QR-Code hoch."));
    return () => {
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  function fromImage(f?: File) {
    if (!f) return;
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = img.width;
      c.height = img.height;
      const x = c.getContext("2d")!;
      x.drawImage(img, 0, 0);
      const r = jsQR(x.getImageData(0, 0, c.width, c.height).data, c.width, c.height);
      if (r?.data) onCode(r.data);
      else setErr("Im Bild wurde kein QR-Code erkannt.");
    };
    img.src = URL.createObjectURL(f);
  }

  return (
    <div className="space-y-3">
      <div className="relative aspect-square bg-bg border border-line-strong rounded-[3px] overflow-hidden grid place-items-center">
        <video ref={video} muted playsInline className="absolute inset-0 size-full object-cover" />
        <div className="relative size-40 border-2 border-accent/80 rounded-[4px]" />
        {err && <div className="absolute inset-x-4 bottom-4 text-[12.5px] text-center bg-bg/90 border border-line rounded-[3px] p-2.5 text-muted">{err}</div>}
      </div>
      <input ref={file} type="file" accept="image/*" hidden onChange={(e) => { fromImage(e.target.files?.[0]); e.target.value = ""; }} />
      <Button variant="ghost" className="w-full" onClick={() => file.current?.click()}><ImageUp size={14} /> QR-Code aus Bild lesen</Button>
    </div>
  );
}

export default function AddContact({ open, onClose, onStart }: { open: boolean; onClose: () => void; onStart: (u: string) => void }) {
  const { me } = useSession();
  const toast = useToast();
  const [tab, setTab] = useState<"code" | "scan" | "mine">("code");
  const [val, setVal] = useState("");
  const [err, setErr] = useState("");

  async function go(input: string) {
    try {
      const r = await addContact(me, input);
      setVal("");
      setErr("");
      toast(r.verified ? "Kontakt hinzugefügt · Schlüssel verifiziert" : "Kontakt hinzugefügt");
      onStart(r.username);
    } catch (e) {
      setErr((e as Error).message);
      setTab("code");
    }
  }

  const tabs = [["code", "Code", ScanLine], ["scan", "Scannen", Camera], ["mine", "Mein Code", ScanLine]] as const;
  return (
    <Modal open={open} onClose={onClose} title="Kontakt hinzufügen">
      <div role="tablist" className="grid grid-cols-3 border border-line-strong rounded-[3px] p-0.5 mb-4 bg-bg">
        {tabs.map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => { setTab(k); setErr(""); }} className={cx("h-8 rounded-[2px] text-[12.5px] font-medium", tab === k ? "bg-raised text-fg" : "text-muted hover:text-fg")}>{l}</button>
        ))}
      </div>
      {tab === "code" && (
        <form onSubmit={(e) => { e.preventDefault(); go(val); }} className="space-y-4">
          <Field label="Kontaktcode oder @Benutzername" hint="Es gibt kein Nutzerverzeichnis">
            <input className={inputCls} value={val} onChange={(e) => setVal(e.target.value)} placeholder="stille://add/mara?k=… oder @mara" autoFocus autoCapitalize="none" spellCheck={false} />
          </Field>
          {err && <div role="alert" className="text-[13px] text-danger">{err}</div>}
          <Button type="submit" className="w-full" disabled={!val.trim()}>Hinzufügen</Button>
        </form>
      )}
      {tab === "scan" && <Scanner onCode={go} />}
      {tab === "mine" && <MyCode size={180} compact />}
    </Modal>
  );
}
