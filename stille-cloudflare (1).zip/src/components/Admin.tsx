import { useState } from "react";
import { Ban, EyeOff, LayoutDashboard, RotateCcw, ScrollText, ShieldAlert, ShieldCheck, Trash2, Users as UsersIcon } from "lucide-react";
import * as S from "../lib/server";
import { useSession } from "../lib/session";
import { Avatar, Button, Chip, Field, Label, Modal, cx, fmtDate, fmtRel, fmtStamp, inputCls, useToast } from "./ui";

type Tab = "overview" | "users" | "audit";

export default function Admin() {
  const db = S.useDB();
  const [tab, setTab] = useState<Tab>("overview");
  const tabs: [Tab, string, typeof UsersIcon, number?][] = [
    ["overview", "Übersicht", LayoutDashboard],
    ["users", "Nutzer", UsersIcon, db.users.filter((u) => !u.bot).length],
    ["audit", "Protokoll", ScrollText],
  ];
  return (
    <div className="flex-1 min-w-0 flex flex-col min-h-0">
      <header className="shrink-0 border-b border-line bg-surface px-4 sm:px-6 pt-4">
        <div className="flex items-center gap-3 mb-3">
          <h1 className="text-[17px] font-semibold tracking-tight">Administration</h1>
          <Chip tone="warn"><ShieldAlert size={10} /> Kein Zugriff auf Nachrichten</Chip>
        </div>
        <div role="tablist" className="flex gap-1 overflow-x-auto -mb-px">
          {tabs.map(([k, l, Icon, n]) => (
            <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={cx("h-9 px-3 flex items-center gap-2 text-[13px] border-b-2 whitespace-nowrap transition-colors", tab === k ? "border-accent text-fg" : "border-transparent text-muted hover:text-fg")}>
              <Icon size={14} /> {l}
              {n !== undefined && <span className="font-mono text-[10.5px] text-faint">{n}</span>}
            </button>
          ))}
        </div>
      </header>
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        <div className="max-w-5xl mx-auto animate-rise" key={tab}>
          {tab === "overview" && <Overview />}
          {tab === "users" && <Users />}
          {tab === "audit" && <Audit />}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="bg-bg p-4">
      <Label>{label}</Label>
      <div className="font-mono text-[32px] leading-none mt-3 tracking-tight">{value}</div>
      {sub && <div className="text-[11.5px] text-faint mt-2">{sub}</div>}
    </div>
  );
}

function Overview() {
  const db = S.useDB();
  const humans = db.users.filter((u) => !u.bot);
  const lastMsg = db.msgs[db.msgs.length - 1];
  const sample = humans[humans.length - 1];

  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (13 - i));
    return { d, n: humans.filter((u) => new Date(u.created).toDateString() === d.toDateString()).length };
  });
  const max = Math.max(1, ...days.map((x) => x.n));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-line border border-line">
        <Stat label="Aktive Nutzer" value={humans.filter((u) => u.status === "active").length} sub={`${humans.filter((u) => u.role === "admin").length} Admin(s)`} />
        <Stat label="Registriert (7 Tage)" value={humans.filter((u) => u.created > Date.now() - 7 * 86400000).length} />
        <Stat label="Gesperrt" value={humans.filter((u) => u.status === "suspended").length} />
        <Stat label="Chiffrate gespeichert" value={S.msgCount} sub="Inhalt nicht lesbar" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <section className="border border-line rounded-[3px] bg-surface">
          <div className="px-4 h-10 flex items-center border-b border-line"><Label>Registrierungen · 14 Tage</Label></div>
          <div className="p-4">
            <div className="flex items-end gap-1.5 h-28">
              {days.map((x, i) => (
                <div key={i} className="flex-1 flex flex-col justify-end h-full" title={`${fmtDate(x.d.getTime())}: ${x.n}`}>
                  <div className={cx("w-full rounded-[1px]", x.n ? "bg-accent" : "bg-line-strong")} style={{ height: x.n ? `${(x.n / max) * 100}%` : "3px" }} />
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-2 font-mono text-[10px] text-faint"><span>{fmtDate(days[0].d.getTime())}</span><span>Heute</span></div>
          </div>
        </section>

        <section className="border border-line rounded-[3px] bg-surface">
          <div className="px-4 h-10 flex items-center border-b border-line"><Label>Sicherheitslage</Label></div>
          <ul className="p-4 space-y-2.5 text-[13px]">
            {[
              ["Ende-zu-Ende", "ECDH P-256 + AES-256-GCM"],
              ["Passphrase-Schutz", "PBKDF2-SHA256 · 210 000 Runden"],
              ["Zugang", "Token nur als SHA-256-Hash gespeichert"],
              ["Login-Drosselung", "30 s Sperre nach 5 Fehlversuchen"],
            ].map(([a, b]) => (
              <li key={a} className="flex items-start gap-2.5"><ShieldCheck size={14} className="text-accent mt-0.5 shrink-0" /><span><span className="text-fg">{a}</span> <span className="text-muted">· {b}</span></span></li>
            ))}
          </ul>
        </section>
      </div>

      <section className="border border-line rounded-[3px] bg-surface">
        <div className="px-4 h-10 flex items-center justify-between border-b border-line"><Label>Was der Server wirklich sieht</Label><EyeOff size={13} className="text-faint" /></div>
        <div className="grid md:grid-cols-2 gap-px bg-line">
          <pre className="bg-bg p-4 font-mono text-[11.5px] leading-relaxed text-muted overflow-x-auto">
{lastMsg ? `{
  id:   "${lastMsg.id}"
  von:  @${lastMsg.from}
  an:   @${lastMsg.to}
  zeit: ${fmtStamp(lastMsg.ts)}
  iv:   "${lastMsg.iv}"
  ct:   "${lastMsg.ct.slice(0, 44)}…"
  text: ‹nicht vorhanden›
}` : "Noch keine Nachrichten gespeichert."}
          </pre>
          <pre className="bg-bg p-4 font-mono text-[11.5px] leading-relaxed text-muted overflow-x-auto">
{sample ? `{
  user:       @${sample.username}
  pub:        "${sample.pub.slice(0, 36)}…"
  priv:       ‹nur auf dem Gerät des Nutzers›
  passwort:   ‹nicht vorhanden›
}` : ""}
          </pre>
        </div>
      </section>

      <section className="border border-danger/30 rounded-[3px] p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-[14px] font-medium text-danger">Instanz zurücksetzen</div>
          <div className="text-[12.5px] text-muted">Löscht alle Nutzer, Chats und Storys auf dem Server.</div>
        </div>
        <AccessCode />
        <ResetButton />
      </section>
    </div>
  );
}

function AccessCode() {
  const [v, setV] = useState("");
  const [msg, setMsg] = useState("");
  const toast = useToast();
  return (
    <form
      className="flex flex-wrap items-end gap-3"
      onSubmit={async (e) => {
        e.preventDefault();
        try {
          await S.setAccessCode(v);
          setV("");
          setMsg("");
          toast("Zugangscode geändert");
        } catch (x) {
          setMsg((x as Error).message);
        }
      }}
    >
      <Field label="Neuer Zugangscode" hint="gilt für neue Mitglieder">
        <input className={inputCls} value={v} onChange={(e) => setV(e.target.value)} autoComplete="off" spellCheck={false} />
      </Field>
      <Button type="submit" variant="ghost" disabled={v.length < 8}>Code ändern</Button>
      {msg && <div className="text-[13px] text-danger w-full">{msg}</div>}
    </form>
  );
}

function ResetButton() {
  const [open, setOpen] = useState(false);
  const { logout } = useSession();
  return (
    <>
      <Button variant="danger" onClick={() => setOpen(true)}><RotateCcw size={14} /> Zurücksetzen</Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Alles löschen?">
        <p className="text-[13.5px] text-muted mb-4">Die Instanz wird in den Ausgangszustand versetzt. Alle Konten, Chats und Storys werden gelöscht.</p>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>Abbrechen</Button>
          <Button variant="danger" onClick={() => { S.resetInstance(); logout(); }}>Ja, zurücksetzen</Button>
        </div>
      </Modal>
    </>
  );
}

function Users() {
  const db = S.useDB();
  const { me } = useSession();
  const toast = useToast();
  const [del, setDel] = useState<S.User | null>(null);
  const users = db.users.filter((u) => !u.bot);
  return (
    <div className="border border-line rounded-[3px] bg-surface overflow-x-auto">
      <table className="w-full min-w-[760px] text-[13px]">
        <thead>
          <tr className="text-left border-b border-line">
            {["Nutzer", "Rolle", "Status", "Beigetreten", "Zuletzt aktiv", ""].map((h) => <th key={h} className="px-4 h-9 font-mono text-[10.5px] uppercase tracking-[0.12em] text-faint font-normal">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {users.map((u) => {
            const self = u.username === me.username;
            return (
              <tr key={u.username} className="border-b border-line last:border-0 hover:bg-raised/50">
                <td className="px-4 py-2.5">
                  <div className="flex items-center gap-3">
                    <Avatar name={u.name} size={28} src={u.avatar} />
                    <div><div className="font-medium leading-tight">{u.name}{self && <span className="text-faint font-normal"> (du)</span>}</div><div className="font-mono text-[11px] text-muted">@{u.username}</div></div>
                  </div>
                </td>
                <td className="px-4">{u.role === "admin" ? <Chip tone="accent">Admin</Chip> : <span className="text-muted">Nutzer</span>}</td>
                <td className="px-4"><Chip tone={u.status === "active" ? "neutral" : "danger"}>{u.status === "active" ? "Aktiv" : "Gesperrt"}</Chip></td>
                <td className="px-4 font-mono text-muted">{fmtDate(u.created)}</td>
                <td className="px-4 text-muted">{fmtRel(u.lastSeen)}</td>
                                <td className="px-4">
                  {!self && (
                    <div className="flex justify-end gap-1">
                      <Button size="sm" variant="quiet" onClick={() => { S.setRole(me.username, u.username, u.role === "admin" ? "user" : "admin"); toast("Rolle geändert", "info"); }}>{u.role === "admin" ? "Zum Nutzer" : "Zum Admin"}</Button>
                      <Button size="sm" variant="quiet" onClick={() => { S.setStatus(me.username, u.username, u.status === "active" ? "suspended" : "active"); toast(u.status === "active" ? "Konto gesperrt" : "Konto entsperrt", "info"); }}>{u.status === "active" ? "Sperren" : "Entsperren"}</Button>
                      <Button size="sm" variant="quiet" onClick={() => setDel(u)} aria-label="Löschen" className="hover:!text-danger"><Trash2 size={13} /></Button>
                    </div>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <Modal open={!!del} onClose={() => setDel(null)} title={`@${del?.username} löschen?`}>
        <p className="text-[13.5px] text-muted mb-4">Konto, Schlüssel und alle Chats dieser Person werden unwiderruflich entfernt.</p>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setDel(null)}>Abbrechen</Button>
          <Button variant="danger" onClick={() => { if (del) S.deleteUser(me.username, del.username); setDel(null); toast("Nutzer gelöscht", "info"); }}>Löschen</Button>
        </div>
      </Modal>
    </div>
  );
}

function Audit() {
  const db = S.useDB();
  return (
    <div className="border border-line rounded-[3px] bg-surface font-mono text-[12px]">
      {db.audit.map((a) => (
        <div key={a.id} className="grid grid-cols-[110px_1fr] sm:grid-cols-[130px_120px_170px_1fr] gap-x-4 gap-y-0.5 px-4 py-2 border-b border-line last:border-0 hover:bg-raised/50">
          <span className="text-faint">{fmtStamp(a.ts)}</span>
          <span className="text-muted truncate">@{a.actor}</span>
          <span className={cx("truncate", a.action.includes("fail") || a.action.includes("blocked") || a.action.includes("delete") || a.action.includes("revoke") ? "text-danger" : "text-accent")}>{a.action}</span>
          <span className="text-muted col-span-2 sm:col-span-1 truncate">{a.detail}</span>
        </div>
      ))}
      {db.audit.length === 0 && <div className="p-10 text-center text-faint">Keine Einträge.</div>}
    </div>
  );
}
