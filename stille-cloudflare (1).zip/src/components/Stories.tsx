import { useEffect, useMemo, useState } from "react";
import { Eye, ImagePlus, Plus, Trash2, Type, X } from "lucide-react";
import * as C from "../lib/crypto";
import { fileToDataUrl } from "../lib/image";
import * as S from "../lib/server";
import { useConvKey, useDecrypted, useSession } from "../lib/session";
import { Avatar, Button, Modal, cx, fmtRel, useToast } from "./ui";
import { useContacts } from "./Profile";

type StoryBody = { kind: "text"; text: string; bg: number } | { kind: "img"; img: string; caption?: string };

const BGS = [
  "linear-gradient(160deg,#c6f45b,#5fae2c)",
  "linear-gradient(160deg,#ff8a5b,#c2362b)",
  "linear-gradient(160deg,#5b8cff,#1c2a78)",
  "linear-gradient(160deg,#f2b84b,#a85a12)",
  "linear-gradient(160deg,#9a6bff,#3b1d7a)",
  "linear-gradient(160deg,#2b3238,#0a0b0c)",
];
const FG = ["#0a0b0c", "#fff", "#fff", "#0a0b0c", "#fff", "#e9ebe6"];

export function StoriesBar() {
  const db = S.useDB();
  const { me } = useSession();
  const [composer, setComposer] = useState(false);
  const [viewing, setViewing] = useState<string | null>(null);

  const mine = db.stories.filter((s) => s.author === me.username && s.to === me.username);
  const authors = useMemo(() => {
    const m = new Map<string, S.Story[]>();
    for (const s of db.stories) if (s.to === me.username && s.author !== me.username) m.set(s.author, [...(m.get(s.author) ?? []), s]);
    return [...m.entries()]
      .map(([a, list]) => ({ user: db.users.find((u) => u.username === a), unseen: list.some((x) => !x.seen), ts: Math.max(...list.map((x) => x.ts)) }))
      .filter((x): x is { user: S.User; unseen: boolean; ts: number } => !!x.user)
      .sort((a, b) => Number(b.unseen) - Number(a.unseen) || b.ts - a.ts);
  }, [db, me.username]);

  return (
    <>
      <div className="flex gap-3 overflow-x-auto px-4 py-3 border-b border-line">
        <div className="flex flex-col items-center gap-1.5 w-14 shrink-0">
          <div className="relative">
            <button onClick={() => (mine.length ? setViewing(me.username) : setComposer(true))} aria-label="Meine Story" className={cx("p-[2px] rounded-[5px] border-2", mine.length ? "border-accent" : "border-line-strong border-dashed")}>
              <Avatar name={me.name} src={me.avatar} size={42} />
            </button>
            <button onClick={() => setComposer(true)} aria-label="Story erstellen" className="absolute -bottom-1 -right-1 size-[18px] rounded-full bg-accent text-bg grid place-items-center border-2 border-surface"><Plus size={11} strokeWidth={3} /></button>
          </div>
          <span className="text-[10.5px] text-muted truncate w-full text-center">Meine</span>
        </div>
        {authors.map(({ user, unseen }) => (
          <button key={user.username} onClick={() => setViewing(user.username)} className="flex flex-col items-center gap-1.5 w-14 shrink-0">
            <span className={cx("p-[2px] rounded-[5px] border-2", unseen ? "border-accent" : "border-line-strong")}><Avatar name={user.name} src={user.avatar} size={42} /></span>
            <span className="text-[10.5px] text-muted truncate w-full text-center">{user.name.split(" ")[0]}</span>
          </button>
        ))}
      </div>
      <StoryComposer open={composer} onClose={() => setComposer(false)} />
      {viewing && <StoryViewer author={viewing} onClose={() => setViewing(null)} />}
    </>
  );
}

function StoryComposer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { me, priv } = useSession();
  const toast = useToast();
  const contacts = useContacts();
  const [mode, setMode] = useState<"text" | "img">("text");
  const [text, setText] = useState("");
  const [bg, setBg] = useState(0);
  const [img, setImg] = useState("");
  const [caption, setCaption] = useState("");
  const [busy, setBusy] = useState(false);

  const body: StoryBody | null = mode === "text" ? (text.trim() ? { kind: "text", text: text.trim(), bg } : null) : img ? { kind: "img", img, caption: caption.trim() || undefined } : null;

  async function post() {
    if (!body) return;
    setBusy(true);
    try {
      const entries = [];
      for (const u of [me, ...contacts]) {
        const key = await C.convKey(priv, u.pub);
        entries.push({ to: u.username, ...(await C.encryptText(key, JSON.stringify(body))) });
      }
      S.postStory(me.username, entries);
      toast(`Story für ${contacts.length} Kontakt${contacts.length === 1 ? "" : "e"} veröffentlicht`);
      setText("");
      setImg("");
      setCaption("");
      onClose();
    } catch {
      toast("Story zu groß für den lokalen Speicher.", "error");
    }
    setBusy(false);
  }

  return (
    <Modal open={open} onClose={onClose} title="Neue Story">
      <div className="grid grid-cols-2 border border-line-strong rounded-[3px] p-0.5 mb-4 bg-bg">
        {([["text", "Text", Type], ["img", "Foto", ImagePlus]] as const).map(([k, l, Icon]) => (
          <button key={k} onClick={() => setMode(k)} className={cx("h-8 rounded-[2px] text-[12.5px] font-medium flex items-center justify-center gap-2", mode === k ? "bg-raised text-fg" : "text-muted")}><Icon size={13} /> {l}</button>
        ))}
      </div>
      <div className="aspect-[9/12] max-h-[360px] mx-auto rounded-[4px] overflow-hidden relative grid place-items-center border border-line" style={mode === "text" ? { background: BGS[bg] } : undefined}>
        {mode === "text" ? (
          <textarea value={text} onChange={(e) => setText(e.target.value.slice(0, 160))} placeholder="Was passiert gerade?" aria-label="Story-Text" className="w-full h-full bg-transparent resize-none text-center text-[24px] font-semibold leading-tight p-6 grid placeholder:opacity-50 focus:outline-none" style={{ color: FG[bg], paddingTop: "30%" }} />
        ) : img ? (
          <>
            <img src={img} alt="" className="size-full object-cover" />
            {caption && <div className="absolute bottom-0 inset-x-0 bg-black/60 text-[14px] p-3 text-center">{caption}</div>}
          </>
        ) : (
          <label className="cursor-pointer text-muted text-[13px] flex flex-col items-center gap-2"><ImagePlus size={24} />Foto auswählen
            <input type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) setImg(await fileToDataUrl(f, 800, 0.7)); }} />
          </label>
        )}
      </div>
      {mode === "text" ? (
        <div className="flex justify-center gap-2 mt-3">
          {BGS.map((b, i) => <button key={i} aria-label={`Hintergrund ${i + 1}`} onClick={() => setBg(i)} className={cx("size-6 rounded-full border-2", bg === i ? "border-fg" : "border-transparent")} style={{ background: b }} />)}
        </div>
      ) : img ? (
        <input value={caption} onChange={(e) => setCaption(e.target.value.slice(0, 80))} placeholder="Bildunterschrift" className="mt-3 w-full h-9 rounded-[3px] bg-bg border border-line-strong px-3 text-[13px] focus:border-accent focus:outline-none" />
      ) : null}
      <div className="flex items-center justify-between mt-4">
        <span className="text-[12px] text-faint">Sichtbar für {contacts.length} Kontakte · 24 Std.</span>
        <Button onClick={post} disabled={!body || busy}>{busy ? "Verschlüssele …" : "Veröffentlichen"}</Button>
      </div>
    </Modal>
  );
}

function StoryViewer({ author, onClose }: { author: string; onClose: () => void }) {
  const db = S.useDB();
  const { me } = useSession();
  const user = db.users.find((u) => u.username === author);
  const isMine = author === me.username;
  const list = useMemo(() => db.stories.filter((s) => s.author === author && s.to === me.username).sort((a, b) => a.ts - b.ts), [db.stories, author, me.username]);
  const key = useConvKey(isMine ? me.pub : user?.pub);
  const get = useDecrypted(list, key);
  const [i, setI] = useState(() => Math.max(0, list.findIndex((s) => !s.seen)));
  const cur = list[Math.min(i, list.length - 1)];
  const raw = cur && get(cur.id);
  const body: StoryBody | null = raw ? JSON.parse(raw) : null;

  useEffect(() => {
    if (!list.length) onClose();
  }, [list.length, onClose]);
  useEffect(() => {
    if (cur && !isMine && body) S.markStorySeen(cur.id);
  }, [cur?.id, isMine, !!body]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") setI((x) => Math.max(0, x - 1));
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });
  const next = () => (i >= list.length - 1 ? onClose() : setI(i + 1));

  if (!cur || !user) return null;
  const views = db.stories.filter((s) => s.sid === cur.sid && s.seen && s.to !== me.username).length;

  return (
    <div className="fixed inset-0 z-[80] bg-black/95 grid place-items-center animate-rise">
      <div className="relative w-full max-w-[420px] h-dvh sm:h-[min(92dvh,760px)] sm:rounded-[6px] overflow-hidden bg-surface" style={body?.kind === "text" ? { background: BGS[body.bg] } : undefined}>
        {body?.kind === "img" && <img src={body.img} alt="" className="absolute inset-0 size-full object-cover" />}
        {body?.kind === "text" && <div className="absolute inset-0 grid place-items-center p-8 text-center text-[30px] font-semibold leading-tight break-words" style={{ color: FG[body.bg] }}>{body.text}</div>}
        {body?.kind === "img" && body.caption && <div className="absolute bottom-16 inset-x-0 bg-black/60 p-3 text-center text-[15px]">{body.caption}</div>}

        <div className="absolute inset-x-0 top-0 p-3 bg-gradient-to-b from-black/60 to-transparent">
          <div className="flex gap-1">
            {list.map((s, k) => (
              <div key={s.id} className="h-[3px] flex-1 bg-white/30 rounded-full overflow-hidden">
                {k < i && <div className="h-full bg-white" />}
                {k === i && body && <div key={cur.id} onAnimationEnd={next} className="h-full bg-white origin-left animate-story" />}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2.5 mt-3 text-white">
            <Avatar name={user.name} src={user.avatar} size={30} />
            <div className="text-[13px] font-medium">{isMine ? "Deine Story" : user.name}</div>
            <div className="text-[11.5px] opacity-70">{fmtRel(cur.ts)}</div>
            <button onClick={onClose} aria-label="Schließen" className="ml-auto p-1"><X size={18} /></button>
          </div>
        </div>

        <button aria-label="Zurück" onClick={() => setI(Math.max(0, i - 1))} className="absolute left-0 top-20 bottom-20 w-1/3" />
        <button aria-label="Weiter" onClick={next} className="absolute right-0 top-20 bottom-20 w-2/3" />

        {isMine && (
          <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/70 to-transparent flex items-center justify-between text-white">
            <span className="flex items-center gap-1.5 text-[13px]"><Eye size={14} /> {views} Aufrufe</span>
            <Button size="sm" variant="ghost" className="!text-white !border-white/30" onClick={() => S.deleteStory(cur.sid)}><Trash2 size={12} /> Löschen</Button>
          </div>
        )}
      </div>
    </div>
  );
}
