import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Loader2, Lock, TriangleAlert } from "lucide-react";
import * as S from "../lib/server";
import { Button, Field, inputCls } from "./ui";
import { PairJoin } from "./Pair";

export type { LoginResult } from "../lib/server";

const GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789+/";
const scramble = (n: number) => Array.from({ length: n }, () => GLYPHS[Math.floor(Math.random() * GLYPHS.length)]).join("");
const PHRASES = [
  "Treffen wir uns um 19 Uhr am Hafen?",
  "Die Unterlagen liegen im Tresor, Code folgt.",
  "Niemand außer dir kann das hier lesen.",
  "Lösch diese Nachricht nach dem Lesen.",
];

function WirePanel() {
  const [i, setI] = useState(0);
  const [plain, setPlain] = useState("");
  const [cipher, setCipher] = useState(scramble(40));

  useEffect(() => {
    const text = PHRASES[i];
    let step = 0;
    const t = setInterval(() => {
      step++;
      const reveal = Math.floor(step * 0.8);
      setPlain(text.split("").map((ch, k) => (k < reveal || ch === " " ? ch : GLYPHS[Math.floor(Math.random() * GLYPHS.length)])).join(""));
      setCipher(scramble(Math.max(36, text.length + 8)));
      if (reveal >= text.length) clearInterval(t);
    }, 40);
    const next = setTimeout(() => setI((x) => (x + 1) % PHRASES.length), 5200);
    return () => {
      clearInterval(t);
      clearTimeout(next);
    };
  }, [i]);

  return (
    <div className="border border-line-strong bg-bg/80 rounded-[3px] font-mono text-[12px] leading-relaxed overflow-hidden">
      <div className="flex items-center justify-between px-3 h-8 border-b border-line text-[10.5px] uppercase tracking-[0.12em] text-faint">
        <span>Leitung</span>
        <span className="flex items-center gap-1.5 text-accent"><span className="size-1.5 rounded-full bg-accent animate-blink" />live</span>
      </div>
      <div className="p-3 space-y-3">
        <div>
          <div className="text-[10.5px] uppercase tracking-[0.12em] text-faint mb-1">Server sieht</div>
          <div className="text-faint break-all h-[3.2em] overflow-hidden">{cipher}</div>
        </div>
        <div className="h-px bg-line" />
        <div>
          <div className="text-[10.5px] uppercase tracking-[0.12em] text-accent mb-1">Empfänger sieht</div>
          <div className="text-fg h-[2.6em]">{plain}</div>
        </div>
      </div>
    </div>
  );
}

function Brand() {
  return (
    <div className="relative hidden lg:flex flex-col justify-between p-12 border-r border-line grid-bg overflow-hidden">
      <div className="flex items-center gap-2.5">
        <div className="size-7 rounded-[3px] bg-accent grid place-items-center"><Lock size={15} className="text-bg" strokeWidth={2.5} /></div>
        <span className="text-[17px] font-semibold tracking-tight">stille</span>
      </div>
      <div className="max-w-[30rem]">
        <h1 className="text-[56px] leading-[0.98] font-semibold tracking-[-0.035em]">
          Nur ein Name.<br /><span className="text-accent">Mehr nicht.</span>
        </h1>
        <p className="mt-6 text-[15px] text-muted leading-relaxed max-w-[26rem]">
          Ein privater Messenger mit Ende-zu-Ende-Verschlüsselung. Keine Telefonnummer, kein Passwort, kein Nutzerverzeichnis, keine Klartexte auf dem Server.
        </p>
        <dl className="mt-10 grid grid-cols-3 gap-px bg-line border border-line text-[12px]">
          {[["ECDH P-256", "Schlüsselaustausch"], ["AES-256-GCM", "Nachrichten"], ["Nur Gerät", "Privater Schlüssel"]].map(([a, b]) => (
            <div key={a} className="bg-bg p-3">
              <dt className="font-mono text-fg">{a}</dt>
              <dd className="text-faint mt-0.5">{b}</dd>
            </div>
          ))}
        </dl>
      </div>
      <WirePanel />
    </div>
  );
}

function ErrorLine({ msg }: { msg: string }) {
  if (!msg) return null;
  return (
    <div role="alert" className="flex items-start gap-2 text-[13px] text-danger bg-danger/10 border border-danger/30 rounded-[3px] px-3 py-2">
      <TriangleAlert size={14} className="mt-0.5 shrink-0" />
      {msg}
    </div>
  );
}

function Submit({ busy, children }: { busy: boolean; children: React.ReactNode }) {
  return (
    <Button type="submit" size="lg" className="w-full" disabled={busy}>
      {busy ? <><Loader2 size={15} className="animate-spin" /> Schlüssel werden berechnet …</> : children}
    </Button>
  );
}

export default function Auth({ onLogin }: { onLogin: (r: S.LoginResult) => void }) {
  const [user, setUser] = useState("");
  const [code, setCode] = useState("");
  const [pair, setPair] = useState(false);
  const [setup, setSetup] = useState(false);
  useEffect(() => {
    S.getStatus().then((r) => {
      if (r.setup) {
        setSetup(true);
        setMode("register");
      }
    });
  }, []);
  const [mode, setMode] = useState<"login" | "register">(S.savedUsername() ? "login" : "register");
  useEffect(() => {
    const u = S.savedUsername();
    if (u) setUser(u);
  }, []);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      onLogin(mode === "login" ? await S.login(user) : await S.register(user, code));
    } catch (x) {
      setErr((x as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="min-h-dvh grid lg:grid-cols-[1.15fr_1fr]">
      <Brand />
      <main className="flex flex-col justify-center px-6 py-10 sm:px-14">
        <div className="w-full max-w-[26rem] mx-auto animate-rise">
          <div className="lg:hidden flex items-center gap-2.5 mb-10">
            <div className="size-7 rounded-[3px] bg-accent grid place-items-center"><Lock size={15} className="text-bg" strokeWidth={2.5} /></div>
            <span className="text-[17px] font-semibold tracking-tight">stille</span>
          </div>
          <h2 className="text-[28px] font-semibold tracking-tight mb-1.5">{setup ? "Ersteinrichtung" : "Los geht's"}</h2>
          <p className="text-[14px] text-muted mb-7">{setup ? "Du bist der Erste: Dein Benutzername wird Administrator, und der Zugangscode, den du jetzt festlegst, gilt für alle weiteren Mitglieder." : mode === "login" ? "Melde dich mit deinem Benutzernamen an. Dein Chat bleibt erhalten." : "Gib den Zugangscode deiner Gruppe ein und wähle einen Benutzernamen. Dein Schlüssel wird auf diesem Gerät erzeugt und bleibt hier."}</p>
          <form onSubmit={submit} className="space-y-4">
            <Field label="Benutzername" hint="3–20 Zeichen: a–z, 0–9, . _ -">
              <input className={inputCls} value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" autoCapitalize="none" spellCheck={false} placeholder="z. B. mara" autoFocus />
            </Field>
            {mode === "register" && <Field label={setup ? "Zugangscode festlegen" : "Zugangscode"} hint={setup ? "min. 8 Zeichen, gib ihn deiner Gruppe" : "Von deiner Gruppe"}>
              <input className={inputCls} type="password" value={code} onChange={(e) => setCode(e.target.value)} autoComplete="off" spellCheck={false} placeholder="••••••••" />
            </Field>}
            <ErrorLine msg={err} />
            <Submit busy={busy}>{mode === "login" ? "Anmelden" : "Konto erstellen"} <ArrowRight size={15} /></Submit>
            <button type="button" onClick={() => { setErr(""); setMode(mode === "login" ? "register" : "login"); }} className="w-full text-center text-[12.5px] text-muted hover:text-fg">
              {mode === "login" ? "Neues Konto mit Zugangscode erstellen" : "Ich habe schon ein Konto auf diesem Gerät"}
            </button>
          </form>
          <button type="button" onClick={() => setPair(true)} className="mt-3 w-full text-center text-[12.5px] text-muted hover:text-fg">Gerät koppeln (Konto von anderem Gerät übernehmen)</button>
          <PairJoin open={pair} onClose={() => setPair(false)} onDone={onLogin} />
          <p className="mt-10 text-[11.5px] text-faint leading-relaxed border-t border-line pt-4">
            Ohne Passwort gehört das Konto zu diesem Browser. Für weitere Geräte nutze „Gerät koppeln“. Löschst du die Websitedaten ohne gekoppeltes Gerät, ist der Chat nicht mehr lesbar.
          </p>
        </div>
      </main>
    </div>
  );
}
