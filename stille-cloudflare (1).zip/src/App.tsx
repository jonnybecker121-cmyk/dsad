import { useCallback, useEffect, useMemo, useState } from "react";
import Auth, { type LoginResult } from "./components/Auth";
import Messenger from "./components/Messenger";
import { ToastProvider, useToast } from "./components/ui";
import * as S from "./lib/server";
import { SessionCtx } from "./lib/session";

function Root() {
  const db = S.useDB();
  const toast = useToast();
  const [auth, setAuth] = useState<LoginResult | null>(null);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    S.resume().then((r) => {
      setAuth(r);
      setBooting(false);
    });
  }, []);

  const logout = useCallback(
    (reason?: string) => {
      S.signOut();
      setAuth(null);
      if (reason) toast(reason, "info");
    },
    [toast],
  );

  useEffect(() => {
    S.setOnExpired(() => {
      S.forgetDevice();
      logout("Dein Konto existiert nicht mehr.");
    });
    return () => void S.setOnExpired(null);
  }, [logout]);

  useEffect(() => {
    if (auth) return S.startSync();
  }, [auth]);

  const me = auth ? db.users.find((u) => u.username === auth.username) : undefined;
  useEffect(() => {
    if (me?.status === "suspended") logout("Dein Konto wurde gesperrt.");
  }, [me?.status, logout]);

  const session = useMemo(() => (me && auth ? { me, priv: auth.priv, logout } : null), [me, auth, logout]);

  if (booting) return null;
  if (!auth) return <Auth onLogin={setAuth} />;
  if (!session) return <div className="min-h-dvh grid place-items-center text-muted text-[13px]">Verbinde …</div>;
  return (
    <SessionCtx.Provider value={session}>
      <Messenger />
    </SessionCtx.Provider>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Root />
    </ToastProvider>
  );
}
