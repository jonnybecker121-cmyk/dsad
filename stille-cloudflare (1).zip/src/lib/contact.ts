import { useEffect, useState } from "react";
import * as C from "./crypto";
import * as S from "./server";

export const shortKey = async (pub: string) => (await C.sha256Hex(pub)).slice(0, 8);
export const buildCode = (username: string, k: string) => `stille://add/${username}?k=${k}`;

export function useContactCode(me: S.User) {
  const [code, setCode] = useState<string | null>(null);
  useEffect(() => {
    shortKey(me.pub).then((k) => setCode(buildCode(me.username, k)));
  }, [me.pub, me.username]);
  return code;
}

export function parseCode(s: string): { username: string; k?: string } | null {
  const m = s.trim().match(/^(?:stille:\/\/add\/)?@?([a-z0-9_.-]{3,20})(?:\?k=([0-9a-f]{8}))?$/i);
  return m ? { username: m[1].toLowerCase(), k: m[2]?.toLowerCase() } : null;
}

const vkey = (me: string, other: string) => `stille.verified.${me}.${other}`;
export const pubTag = (u: S.User) => u.pub.slice(-24);
export const isVerified = (me: string, u: S.User) => localStorage.getItem(vkey(me, u.username)) === pubTag(u);
export const setVerified = (me: string, u: S.User, v: boolean) =>
  v ? localStorage.setItem(vkey(me, u.username), pubTag(u)) : localStorage.removeItem(vkey(me, u.username));

export async function addContact(me: S.User, input: string): Promise<{ username: string; verified: boolean }> {
  const p = parseCode(input);
  if (!p) throw new Error("Das ist kein gültiger Kontaktcode.");
  const user = await S.lookupUser(p.username);
  if (!user || user.username === me.username) throw new Error("Kein aktiver Nutzer mit diesem Code gefunden.");
  let verified = false;
  if (p.k) {
    if ((await shortKey(user.pub)) !== p.k) throw new Error("Der Schlüssel passt nicht zum Code. Die Identität könnte sich geändert haben.");
    verified = true;
    setVerified(me.username, user, true);
  }
  S.startConv(me.username, user.username);
  return { username: user.username, verified };
}
