export type Payload =
  | { t: "text"; text: string }
  | { t: "card"; username: string; name: string; bio?: string; avatar?: string; k: string }
  | { t: "img"; img: string; caption?: string; once?: boolean }
  | { t: "react"; target: string; emoji: string };

export const encodePayload = (p: Payload) => (p.t === "text" ? p.text : "\u0001" + JSON.stringify(p));

export function decodePayload(s: string): Payload {
  if (s.startsWith("\u0001")) {
    try {
      return JSON.parse(s.slice(1)) as Payload;
    } catch {
      /* fall through */
    }
  }
  return { t: "text", text: s };
}

export function previewOf(p: Payload): string {
  switch (p.t) {
    case "text": return p.text;
    case "card": return `Profil: ${p.name}`;
    case "img": return p.once ? "Einmal-Foto" : p.caption ? `Foto: ${p.caption}` : "Foto";
    case "react": return `Reaktion ${p.emoji}`;
  }
}
