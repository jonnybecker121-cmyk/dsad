import { useSyncExternalStore } from "react";
import * as C from "./crypto";

export type Role = "admin" | "user";

export interface User extends C.IdentityRecord {
  username: string;
  name: string;
  role: Role;
  status: "active" | "suspended";
  created: number;
  lastSeen: number;
  bot?: boolean;
  avatar?: string;
  bio?: string;
  mood?: string;
  prefs: { receipts: boolean; blurOnBlur: boolean; autoLock: number; showSeen?: boolean };
}

export interface Conv {
  id: string;
  members: [string, string];
  ttl: number;
  created: number;
}
export interface Msg {
  id: string;
  conv: string;
  from: string;
  to: string;
  iv: string;
  ct: string;
  ts: number;
  exp: number | null;
  read: boolean;
  rr: boolean;
  once?: boolean;
  opened?: boolean;
}
export interface Story {
  id: string;
  sid: string;
  author: string;
  to: string;
  iv: string;
  ct: string;
  ts: number;
  exp: number;
  seen: boolean;
}
export interface AuditEntry {
  id: string;
  ts: number;
  actor: string;
  action: string;
  detail: string;
}
export interface DB {
  users: User[];
  convs: Conv[];
  msgs: Msg[];
  audit: AuditEntry[];
  stories: Story[];
}

// ---------- lokaler Cache (Sicht des angemeldeten Nutzers, vom Server synchronisiert) ----------
const empty = (): DB => ({ users: [], convs: [], msgs: [], audit: [], stories: [] });
let db: DB = empty();
let version = 0;
let rev = -1;
export let msgCount = 0;
const listeners = new Set<() => void>();
const emit = () => {
  version++;
  listeners.forEach((l) => l());
};
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => void listeners.delete(cb);
};
export const getDB = () => db;
export function useDB(): DB {
  useSyncExternalStore(subscribe, () => version);
  return db;
}
// Lokale (optimistische) Änderung – der Server bleibt die Wahrheit und überschreibt beim nächsten Sync.
function local(fn: (d: DB) => void) {
  const d = structuredClone(db);
  fn(d);
  db = d;
  emit();
}
export const mutate = local;

// ---------- Anmeldung: nur Benutzername, Gerät merkt sich Schlüssel + Token ----------
export interface LoginResult {
  username: string;
  priv: CryptoKey;
}
const SKEY = "stille.session.v2";
let auth: { username: string; token: string } | null = null;

const idb = () =>
  new Promise<IDBDatabase>((res, rej) => {
    const r = indexedDB.open("stille", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("keys");
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
async function keyStore<T>(mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const d = await idb();
  return new Promise((res, rej) => {
    const q = f(d.transaction("keys", mode).objectStore("keys"));
    q.onsuccess = () => res(q.result);
    q.onerror = () => rej(q.error);
  });
}

export const normUser = (s: string) => s.trim().toLowerCase();
export const validUsername = (s: string) => /^[a-z0-9_.-]{3,20}$/.test(s);
export const convId = (a: string, b: string) => [a, b].sort().join("|");

async function api<T = any>(path: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const headers: Record<string, string> = {};
  if (auth) {
    headers["x-user"] = auth.username;
    headers.authorization = "Bearer " + auth.token;
  }
  if (init?.json) headers["content-type"] = "application/json";
  let r: Response;
  try {
    r = await fetch(path, { ...init, headers, body: init?.json ? JSON.stringify(init.json) : undefined });
  } catch {
    throw new Error("Keine Verbindung zum Server.");
  }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401 && auth) onExpired?.();
    throw new Error(data.error ?? "Serverfehler");
  }
  return data;
}
let onExpired: (() => void) | null = null;
export const setOnExpired = (f: (() => void) | null) => (onExpired = f);

export async function register(username: string, code: string): Promise<LoginResult> {
  const u = normUser(username);
  if (!validUsername(u)) throw new Error("Benutzername: 3–20 Zeichen, a–z, 0–9, . _ -");
  const { pub, priv } = await C.createIdentity();
  const token = C.b64(C.rand(32)).replace(/[+/=]/g, "x");
  await api("/api/register", { method: "POST", json: { username: u, pub, token, code } });
  await keyStore("readwrite", (s) => s.put(priv, "priv:" + u));
  localStorage.setItem(SKEY, JSON.stringify({ username: u, token }));
  auth = { username: u, token };
  return { username: u, priv };
}

export async function resume(): Promise<LoginResult | null> {
  try {
    const saved = JSON.parse(localStorage.getItem(SKEY) ?? "null");
    if (!saved?.username || !saved?.token) return null;
    const priv = await keyStore<CryptoKey | undefined>("readonly", (s) => s.get("priv:" + saved.username));
    if (!priv) return null;
    auth = saved;
    return { username: saved.username, priv };
  } catch {
    return null;
  }
}

/** Alter Gerät: erzeugt Kopplungscode (QR) + PIN. Der Code enthält Schlüssel und Token, verschlüsselt mit der PIN. */
export async function exportPairing() {
  if (!auth) throw new Error("Nicht angemeldet.");
  const priv = await keyStore<CryptoKey | undefined>("readonly", (s) => s.get("priv:" + auth!.username));
  if (!priv) throw new Error("Schlüssel nicht gefunden.");
  const pin = C.makePin();
  const key = C.b64(await crypto.subtle.exportKey("pkcs8", priv));
  return { pin, code: await C.sealPairing({ u: auth.username, t: auth.token, k: key }, pin) };
}
/** Neues Gerät: übernimmt Konto und Schlüssel. */
export async function importPairing(code: string, pin: string): Promise<LoginResult> {
  const d = await C.openPairing<{ u: string; t: string; k: string }>(code, pin);
  const priv = await crypto.subtle.importKey("pkcs8", C.unb64(d.k), { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  auth = { username: d.u, token: d.t };
  try {
    await api("/api/sync?rev=-1");
  } catch (e) {
    auth = null;
    throw e;
  }
  await keyStore("readwrite", (s) => s.put(priv, "priv:" + d.u));
  localStorage.setItem(SKEY, JSON.stringify(auth));
  return { username: d.u, priv };
}

export const savedUsername = (): string | null => {
  try {
    return JSON.parse(localStorage.getItem(SKEY) ?? "null")?.username ?? null;
  } catch {
    return null;
  }
};

/** Anmelden mit Benutzername: klappt auf dem Gerät, auf dem das Konto angelegt wurde (Schlüssel liegt dort). */
export async function login(username: string): Promise<LoginResult> {
  if (savedUsername() !== normUser(username)) throw new Error("Auf diesem Gerät ist dieses Konto nicht gespeichert.");
  const r = await resume();
  if (!r) throw new Error("Schlüssel auf diesem Gerät nicht gefunden.");
  await sync().catch((e) => {
    auth = null;
    throw e;
  });
  return r;
}

/** Beendet nur die Sitzung. Schlüssel und Chats bleiben erhalten, man liest nach dem Anmelden weiter. */
export function signOut() {
  auth = null;
  rev = -1;
  db = empty();
  emit();
}

/** Entfernt Schlüssel und Token von diesem Gerät. Das Konto ist danach auf diesem Gerät nicht wiederherstellbar. */
export async function forgetDevice() {
  const u = auth?.username;
  auth = null;
  rev = -1;
  localStorage.removeItem(SKEY);
  if (u) await keyStore("readwrite", (s) => s.delete("priv:" + u)).catch(() => {});
  db = empty();
  emit();
}

// ---------- Synchronisation (Polling mit Revisionsnummer) ----------
export async function sync() {
  if (!auth) return;
  const r = await api<{ rev: number; same?: boolean; db?: DB; msgCount?: number }>(`/api/sync?rev=${rev}`);
  if (r.same || !r.db) return;
  rev = r.rev;
  msgCount = r.msgCount ?? 0;
  db = { ...empty(), ...r.db };
  emit();
}
export function startSync() {
  let stop = false;
  const tick = async () => {
    if (stop) return;
    if (!document.hidden) await sync().catch(() => {});
    setTimeout(tick, document.hidden ? 8000 : 2000);
  };
  tick();
  return () => void (stop = true);
}

function op(body: Record<string, unknown>) {
  return api("/api/op", { method: "POST", json: body }).then(() => sync()).catch(() => sync().catch(() => {}));
}

export async function lookupUser(username: string): Promise<User | null> {
  const u = normUser(username);
  if (!validUsername(u)) return null;
  const r = await api<{ user: User }>("/api/user/" + encodeURIComponent(u)).catch(() => null);
  if (!r) return null;
  local((d) => {
    if (!d.users.some((x) => x.username === u)) d.users.push(r.user);
  });
  return r.user;
}

// ---------- Aktionen (lokal sofort sichtbar, dann an den Server) ----------
const uid = () => C.b64(C.rand(9)).replace(/[+/=]/g, "x");

export function touch(username: string) {
  op({ op: "touch", username });
}
export function startConv(a: string, b: string) {
  if (db.convs.some((c) => c.id === convId(a, b))) return;
  local((d) => d.convs.push({ id: convId(a, b), members: [a, b].sort() as [string, string], ttl: 0, created: Date.now() }));
  op({ op: "startConv", to: b });
}
export function sendMsg(from: string, to: string, iv: string, ct: string, once = false) {
  const id = uid();
  const ts = Date.now();
  local((d) => {
    const cid = convId(from, to);
    const c = d.convs.find((x) => x.id === cid);
    d.msgs.push({ id, conv: cid, from, to, iv, ct, ts, exp: c?.ttl ? ts + c.ttl * 1000 : null, read: false, rr: false, ...(once ? { once: true } : {}) });
  });
  op({ op: "sendMsg", id, to, iv, ct, once });
}
export function markRead(conv: string, me: string, receipt: boolean) {
  if (!db.msgs.some((m) => m.conv === conv && m.to === me && !m.read)) return;
  local((d) => d.msgs.forEach((m) => { if (m.conv === conv && m.to === me && !m.read) { m.read = true; m.rr = receipt; } }));
  op({ op: "markRead", conv, receipt });
}
export function setTtl(conv: string, ttl: number) {
  local((d) => { const c = d.convs.find((x) => x.id === conv); if (c) c.ttl = ttl; });
  op({ op: "setTtl", conv, ttl });
}
export function clearConv(conv: string) {
  local((d) => { d.msgs = d.msgs.filter((m) => m.conv !== conv); });
  op({ op: "clearConv", conv });
}
export function purgeExpired() {
  const now = Date.now();
  if (!db.msgs.some((m) => m.exp && m.exp < now) && !db.stories.some((s) => s.exp < now)) return;
  local((d) => {
    d.msgs = d.msgs.filter((m) => !(m.exp && m.exp < now));
    d.stories = d.stories.filter((s) => s.exp >= now);
  });
}
export function consumeOnce(id: string) {
  local((d) => { const m = d.msgs.find((x) => x.id === id); if (m && m.once && !m.opened) { m.opened = true; m.iv = ""; m.ct = ""; } });
  op({ op: "consumeOnce", id });
}
export function updateProfile(username: string, p: { name?: string; bio?: string; mood?: string; avatar?: string | null }) {
  local((d) => {
    const u = d.users.find((x) => x.username === username);
    if (!u) return;
    if (p.name !== undefined) u.name = p.name.trim() || u.username;
    if (p.bio !== undefined) u.bio = p.bio.slice(0, 140);
    if (p.mood !== undefined) u.mood = p.mood;
    if (p.avatar !== undefined) { if (p.avatar) u.avatar = p.avatar; else delete u.avatar; }
  });
  op({ op: "updateProfile", profile: p });
}
export function updatePrefs(username: string, p: Partial<User["prefs"]>) {
  local((d) => { const u = d.users.find((x) => x.username === username); if (u) Object.assign(u.prefs, p); });
  op({ op: "updatePrefs", prefs: p });
}
export function postStory(author: string, entries: { to: string; iv: string; ct: string }[]) {
  op({ op: "postStory", entries });
}
export function markStorySeen(id: string) {
  const s = db.stories.find((x) => x.id === id);
  if (!s || s.seen) return;
  local((d) => { const x = d.stories.find((y) => y.id === id); if (x) x.seen = true; });
  op({ op: "markStorySeen", id });
}
export function deleteStory(sid: string) {
  local((d) => { d.stories = d.stories.filter((s) => s.sid !== sid); });
  op({ op: "deleteStory", sid });
}
export async function deleteSelf(_username: string) {
  await api("/api/op", { method: "POST", json: { op: "deleteSelf" } });
  await forgetDevice();
  onExpired?.();
}

// ---------- Administration ----------
export const setStatus = (_a: string, username: string, status: User["status"]) => op({ op: "setStatus", username, status });
export const setRole = (_a: string, username: string, role: Role) => op({ op: "setRole", username, role });
export const deleteUser = (_a: string, username: string) => op({ op: "deleteUser", username });
export async function resetInstance() {
  await api("/api/op", { method: "POST", json: { op: "resetInstance" } });
  await forgetDevice();
  onExpired?.();
}

export const getStatus = () => api<{ setup: boolean }>("/api/status").catch(() => ({ setup: false }));
export const setAccessCode = (code: string) => api("/api/code", { method: "POST", json: { code } });
