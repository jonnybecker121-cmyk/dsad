const enc = new TextEncoder();
const dec = new TextDecoder();

export const b64 = (buf: ArrayBuffer | Uint8Array): string => {
  const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = "";
  u.forEach((x) => (s += String.fromCharCode(x)));
  return btoa(s);
};
export const unb64 = (s: string): Uint8Array<ArrayBuffer> =>
  Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
export const rand = (n: number) => crypto.getRandomValues(new Uint8Array(n));

export async function sha256Hex(s: string) {
  const h = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)));
  return Array.from(h, (x) => x.toString(16).padStart(2, "0")).join("");
}


export interface IdentityRecord {
  pub: string;
}

const ECDH = { name: "ECDH", namedCurve: "P-256" } as const;

// Schlüsselpaar entsteht im Browser und bleibt auf dem Gerät (IndexedDB, siehe server.ts).
// Exportierbar nur, damit man ihn per verschlüsseltem QR-Code auf ein weiteres Gerät koppeln kann.
export async function createIdentity(): Promise<{ pub: string; priv: CryptoKey }> {
  const kp = await crypto.subtle.generateKey(ECDH, true, ["deriveBits"]);
  return { pub: b64(await crypto.subtle.exportKey("spki", kp.publicKey)), priv: kp.privateKey };
}

export async function convKey(myPriv: CryptoKey, theirPub: string): Promise<CryptoKey> {
  const pub = await crypto.subtle.importKey("spki", unb64(theirPub), ECDH, false, []);
  const bits = await crypto.subtle.deriveBits({ name: "ECDH", public: pub }, myPriv, 256);
  const hk = await crypto.subtle.importKey("raw", bits, "HKDF", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "HKDF", hash: "SHA-256", salt: enc.encode("stille-v1"), info: enc.encode("message-key") },
    hk,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

export async function encryptText(key: CryptoKey, text: string) {
  const iv = rand(12);
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(text));
  return { iv: b64(iv), ct: b64(ct) };
}

export async function decryptText(key: CryptoKey, iv: string, ct: string) {
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(iv) }, key, unb64(ct));
  return dec.decode(pt);
}

export async function safetyNumber(pubA: string, pubB: string): Promise<string[]> {
  const [x, y] = [pubA, pubB].sort();
  const h1 = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(x + y)));
  const h2 = new Uint8Array(await crypto.subtle.digest("SHA-256", h1));
  const digits = [...h1, ...h2].slice(0, 60).map((n) => n % 10).join("");
  return digits.match(/.{5}/g)!;
}

export async function fingerprint(pub: string): Promise<string[]> {
  const hex = await sha256Hex(pub);
  return hex.slice(0, 32).match(/.{4}/g)!;
}

// ---------- Gerätekopplung: Schlüssel + Token, mit einmaliger PIN verschlüsselt ----------
const pinKey = async (pin: string, salt: Uint8Array<ArrayBuffer>) => {
  const base = await crypto.subtle.importKey("raw", enc.encode(pin.replace(/\D/g, "")), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 600000, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
};
export const makePin = () => Array.from(rand(10), (x) => x % 10).join("");
export async function sealPairing(data: object, pin: string): Promise<string> {
  const salt = rand(16), iv = rand(12);
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await pinKey(pin, salt), enc.encode(JSON.stringify(data)));
  return `stille://pair/${b64(salt)}.${b64(iv)}.${b64(ct)}`.replace(/\+/g, "-").replace(/\//g, "_");
}
export async function openPairing<T>(code: string, pin: string): Promise<T> {
  const m = /^stille:\/\/pair\/([^.]+)\.([^.]+)\.(.+)$/.exec(code.trim().replace(/-/g, "+").replace(/_/g, "/"));
  if (!m) throw new Error("Das ist kein Kopplungscode.");
  try {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(m[2]) }, await pinKey(pin, unb64(m[1])), unb64(m[3]));
    return JSON.parse(dec.decode(pt));
  } catch {
    throw new Error("PIN falsch oder Code beschädigt.");
  }
}
