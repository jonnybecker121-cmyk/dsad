import { createContext, useContext, useEffect, useRef, useState } from "react";
import * as C from "./crypto";
import type { User } from "./server";

export interface Session {
  me: User;
  priv: CryptoKey;
  logout: (reason?: string) => void;
}
export const SessionCtx = createContext<Session>(null as unknown as Session);
export const useSession = () => useContext(SessionCtx);

export function useConvKey(partnerPub?: string) {
  const { priv } = useSession();
  const [key, setKey] = useState<CryptoKey | null>(null);
  useEffect(() => {
    let off = false;
    setKey(null);
    if (partnerPub) C.convKey(priv, partnerPub).then((k) => !off && setKey(k));
    return () => {
      off = true;
    };
  }, [priv, partnerPub]);
  return key;
}

export function useDecrypted(msgs: { id: string; iv: string; ct: string }[], key: CryptoKey | null) {
  const cache = useRef(new Map<string, string>());
  const [, tick] = useState(0);
  useEffect(() => {
    if (!key) return;
    let off = false;
    (async () => {
      let changed = false;
      for (const m of msgs) {
        if (cache.current.has(m.id)) continue;
        if (!m.ct) {
          cache.current.set(m.id, "");
          continue;
        }
        try {
          cache.current.set(m.id, await C.decryptText(key, m.iv, m.ct));
        } catch {
          cache.current.set(m.id, "Nicht entschlüsselbar");
        }
        changed = true;
      }
      if (changed && !off) tick((n) => n + 1);
    })();
    return () => {
      off = true;
    };
  }, [msgs, key]);
  return (id: string) => cache.current.get(id);
}
