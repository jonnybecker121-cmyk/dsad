# Stille – privater Messenger (Cloudflare-Version)

Zugang nur mit **Gruppen-Zugangscode + Benutzername**. Kein Passwort pro Person.
Das Schlüsselpaar entsteht im Browser, der private Schlüssel bleibt auf dem Gerät (nicht exportierbar, IndexedDB).
Der Server (Cloudflare Worker + Durable Object mit SQLite) sieht nur Chiffretext.

## Deployen (ohne Terminal)

1. Projekt in ein GitHub-Repository hochladen (ZIP entpacken, Dateien pushen).
2. Cloudflare Dashboard → **Workers & Pages → Create → Import a repository** → Repo wählen.
3. Alle Voreinstellungen lassen und **Deploy** klicken. Gebaut wird automatisch (steht in `wrangler.jsonc`).
4. Die URL öffnen. Beim ersten Besuch ist die **Ersteinrichtung** dran: Benutzername wählen und den
   **Zugangscode** festlegen. Du bist dann Administrator. Gib den Code nur deiner Gruppe.

Öffne die URL sofort nach dem Deploy selbst, denn wer zuerst kommt, wird Admin.
Optional: In `wrangler.jsonc` `ADMIN_USERNAME` setzen, dann kann nur dieser Name Admin werden;
oder `ACCESS_CODE` als Secret setzen, dann ist der Code fest vorgegeben.
Den Code später ändern: Administration → Übersicht → „Zugangscode“.
Falscher Code: nach 5 Versuchen 60 s Sperre pro IP.

Per Terminal geht es auch: `pnpm install && npx wrangler login && pnpm deploy`. Lokal testen: `pnpm build && pnpm cf:dev`.

## Weiteres Gerät koppeln

Einstellungen → „Gerät koppeln“ zeigt einen QR-Code und eine 10-stellige PIN (2 Minuten gültig).
Auf dem neuen Gerät: Anmeldeseite → „Gerät koppeln“, QR scannen (oder Text einfügen), PIN eingeben.
Der Schlüssel wird mit der PIN verschlüsselt (PBKDF2 600k + AES-GCM) und läuft nie über den Server.

## Chat-Befehle

- `/clear` – Verlauf für **beide** Seiten auf dem Server löschen
- `/timer 24h` (auch `30s`, `5m`, `1h`, `7d`, `off`) – automatisches Löschen, gilt auch für vorhandene Nachrichten;
  der Server löscht abgelaufene Nachrichten selbstständig (Alarm), auch wenn niemand online ist
- `/help`

Abmelden beendet nur die Sitzung: Schlüssel und Chat bleiben, nach dem Anmelden liest man weiter. Chats verschwinden nur per `/clear` oder `/timer`.

Danach sofort die URL öffnen und **zuerst selbst** den Admin-Namen registrieren.
Lokal testen: `pnpm cf:dev` (http://localhost:8787).

## Aufbau

- `src/` – React-App (Vite). `src/lib/server.ts` ist der API-Client (Polling alle 2 s).
- `worker/index.ts` – API (`/api/*`), Rechteprüfung pro Aktion, Speicher in SQLite.
- `wrangler.jsonc` – Worker, statische Dateien (SPA-Fallback), Durable Object.

## Grenzen

- Kein Passwort = Konto gehört zum Browser. Datenverlust oder neues Gerät heißt: neues Konto.
- Registrierung ist offen. Spam-Schutz z. B. über Cloudflare Rate Limiting Rules für `POST /api/register`.
- Alle Daten liegen in einer Durable Object (gut für Freundeskreis-Größe, nicht für Tausende Nutzer).
