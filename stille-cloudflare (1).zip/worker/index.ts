import { DurableObject } from "cloudflare:workers";

interface Env {
  HUB: DurableObjectNamespace<Hub>;
  ADMIN_USERNAME?: string;
  ACCESS_CODE?: string; // Geheimer Gruppencode (wrangler secret put ACCESS_CODE)
}
type Row = Record<string, any>;

export default {
  fetch(req: Request, env: Env) {
    return env.HUB.get(env.HUB.idFromName("main")).fetch(req);
  },
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const bad = (msg: string, status = 400) => json({ error: msg }, status);
const NAME = /^[a-z0-9_.-]{3,20}$/;
const uid = () => crypto.randomUUID().replace(/-/g, "").slice(0, 12);
async function sha(s: string) {
  const h = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)));
  return Array.from(h, (x) => x.toString(16).padStart(2, "0")).join("");
}

// Eine Durable Object = ein konsistenter Server für alle Nutzer. Daten liegen in SQLite.
export class Hub extends DurableObject<Env> {
  private rev = 0;
  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    ctx.storage.sql.exec("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL)");
    this.rev = this.get<number>("rev") ?? 0;
  }
  private get<T>(k: string): T | undefined {
    const r = this.ctx.storage.sql.exec("SELECT v FROM kv WHERE k=?", k).toArray()[0];
    return r ? (JSON.parse(r.v as string) as T) : undefined;
  }
  private put(k: string, v: unknown) {
    this.ctx.storage.sql.exec("INSERT OR REPLACE INTO kv (k,v) VALUES (?,?)", k, JSON.stringify(v));
  }
  private del(k: string) {
    this.ctx.storage.sql.exec("DELETE FROM kv WHERE k=?", k);
  }
  private all<T = Row>(prefix: string): T[] {
    return this.ctx.storage.sql.exec("SELECT v FROM kv WHERE k LIKE ?", prefix + "%").toArray().map((r) => JSON.parse(r.v as string));
  }
  private bump() {
    this.put("rev", ++this.rev);
  }
  private log(actor: string, action: string, detail = "") {
    const ts = Date.now();
    this.put(`a:${String(ts).padStart(14, "0")}${uid()}`, { id: uid(), ts, actor, action, detail });
    this.ctx.storage.sql.exec("DELETE FROM kv WHERE k LIKE 'a:%' AND k NOT IN (SELECT k FROM kv WHERE k LIKE 'a:%' ORDER BY k DESC LIMIT 300)");
  }
  private purge() {
    const now = Date.now();
    const sql = this.ctx.storage.sql;
    sql.exec("DELETE FROM kv WHERE k LIKE 'm:%' AND json_extract(v,'$.exp') IS NOT NULL AND json_extract(v,'$.exp') < ?", now);
    sql.exec("DELETE FROM kv WHERE k LIKE 's:%' AND json_extract(v,'$.exp') < ?", now);
  }
  private pub(u: Row) {
    const { tokenHash, ...rest } = u;
    return rest;
  }
  private ensureConv(a: string, b: string) {
    const id = [a, b].sort().join("|");
    if (!this.get(`c:${id}`)) this.put(`c:${id}`, { id, members: [a, b].sort(), ttl: 0, created: Date.now() });
    return this.get<Row>(`c:${id}`)!;
  }
  private async codeHash(): Promise<string | undefined> {
    const env = (this.env.ACCESS_CODE ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    return env ? await sha(env) : this.get<string>("accessCodeHash");
  }
  private arm() {
    void this.ctx.storage.setAlarm(Date.now() + 15_000);
  }
  // Löscht abgelaufene Nachrichten/Storys auch ohne Anfragen und plant sich neu, solange Timer laufen.
  async alarm() {
    this.purge();
    const n = this.ctx.storage.sql.exec("SELECT COUNT(*) c FROM kv WHERE k LIKE 'm:%' AND json_extract(v,'$.exp') IS NOT NULL").one().c as number;
    if (n > 0) this.arm();
    this.bump();
  }
  private purgeUser(name: string) {
    const gone = this.all("c:").filter((c) => c.members.includes(name)).map((c) => c.id);
    for (const id of gone) this.del(`c:${id}`);
    for (const m of this.all("m:")) if (gone.includes(m.conv)) this.del(`m:${m.id}`);
    for (const s of this.all("s:")) if (s.author === name || s.to === name) this.del(`s:${s.id}`);
    this.del(`u:${name}`);
  }

  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    try {
      if (req.method === "GET" && url.pathname === "/api/status") return json({ setup: !(await this.codeHash()) && this.all("u:").length === 0 });
      if (req.method === "POST" && url.pathname === "/api/register") return await this.register(await req.json(), req.headers.get("cf-connecting-ip") ?? "local");

      const name = (req.headers.get("x-user") ?? "").toLowerCase();
      const token = (req.headers.get("authorization") ?? "").replace(/^Bearer /, "");
      const me = this.get<Row>(`u:${name}`);
      if (!me || !token || me.tokenHash !== (await sha(token))) return bad("Nicht angemeldet.", 401);
      this.purge();

      if (req.method === "GET" && url.pathname === "/api/sync") return this.sync(me, Number(url.searchParams.get("rev") ?? -1));
      if (req.method === "GET" && url.pathname.startsWith("/api/user/")) {
        const u = this.get<Row>(`u:${decodeURIComponent(url.pathname.slice(10)).toLowerCase()}`);
        return u && u.status === "active" ? json({ user: this.pub(u) }) : bad("Nicht gefunden.", 404);
      }
      if (req.method === "POST" && url.pathname === "/api/code") {
        if (me.role !== "admin") return bad("Nicht erlaubt.", 403);
        if (this.env.ACCESS_CODE) return bad("Der Code ist über die Cloudflare-Variable ACCESS_CODE festgelegt.");
        const c = String(((await req.json()) as Row).code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
        if (c.length < 8) return bad("Mindestens 8 Buchstaben/Zahlen.");
        this.put("accessCodeHash", await sha(c));
        this.log(me.username, "access.code", "Zugangscode geändert");
        this.bump();
        return json({ ok: true });
      }
      if (req.method === "POST" && url.pathname === "/api/op") {
        if (me.status === "suspended") return bad("Konto gesperrt.", 403);
        const r = this.op(me, await req.json());
        if (r) return r;
        this.bump();
        return json({ ok: true, rev: this.rev });
      }
      return bad("Nicht gefunden.", 404);
    } catch (e) {
      return bad((e as Error).message || "Serverfehler", 400);
    }
  }

  private fails = new Map<string, { n: number; until: number }>();
  private async register(b: Row, ip: string) {
    const norm = (x: string) => x.toUpperCase().replace(/[^A-Z0-9]/g, "");
    let hash = await this.codeHash();
    const first = !hash && this.all("u:").length === 0;
    if (!hash && !first) return bad("Server nicht eingerichtet. Ein Admin muss einen Zugangscode setzen.", 503);
    const f = this.fails.get(ip) ?? { n: 0, until: 0 };
    if (f.until > Date.now()) return bad(`Zu viele Versuche. Bitte ${Math.ceil((f.until - Date.now()) / 1000)} s warten.`, 429);
    if (first && norm(String(b.code ?? "")).length < 8) return bad("Lege einen Zugangscode mit mindestens 8 Buchstaben/Zahlen fest.");
    const given = await sha(norm(String(b.code ?? "")));
    if (!first && given !== hash) {
      if (++f.n >= 5) Object.assign(f, { n: 0, until: Date.now() + 60_000 });
      this.fails.set(ip, f);
      return bad("Zugangscode falsch.", 403);
    }
    const u = String(b.username ?? "").trim().toLowerCase();
    if (!NAME.test(u)) return bad("Benutzername: 3–20 Zeichen, a–z, 0–9, . _ -");
    if (typeof b.pub !== "string" || b.pub.length > 400 || typeof b.token !== "string" || b.token.length < 32) return bad("Ungültige Anfrage.");
    if (this.get(`u:${u}`)) return bad("Dieser Benutzername ist bereits vergeben.", 409);
    if (first) this.put("accessCodeHash", given);
    const configured = (this.env.ADMIN_USERNAME ?? "").trim().toLowerCase();
    const admin = configured ? u === configured : this.all("u:").length === 0;
    const now = Date.now();
    this.put(`u:${u}`, {
      username: u, name: u, role: admin ? "admin" : "user", status: "active", created: now, lastSeen: now,
      prefs: { receipts: true, blurOnBlur: false, autoLock: 0 }, pub: b.pub, tokenHash: await sha(b.token),
    });
    this.log(u, "user.register", admin ? "Administrator" : "");
    this.bump();
    return json({ ok: true });
  }

  private sync(me: Row, since: number) {
    if (since === this.rev) return json({ rev: this.rev, same: true });
    const n = me.username as string;
    const convs = this.all("c:").filter((c) => c.members.includes(n));
    const msgs = this.all("m:").filter((m) => m.from === n || m.to === n).sort((a, b) => a.ts - b.ts);
    const stories = this.all("s:").filter((s) => s.to === n || s.author === n);
    const admin = me.role === "admin";
    const names = new Set<string>([n]);
    convs.forEach((c) => c.members.forEach((m: string) => names.add(m)));
    stories.forEach((s) => names.add(s.author));
    const users = this.all("u:").filter((u) => admin || names.has(u.username)).map((u) => this.pub(u));
    const audit = admin
      ? this.ctx.storage.sql.exec("SELECT v FROM kv WHERE k LIKE 'a:%' ORDER BY k DESC LIMIT 300").toArray().map((r) => JSON.parse(r.v as string))
      : [];
    const msgCount = admin ? (this.ctx.storage.sql.exec("SELECT COUNT(*) c FROM kv WHERE k LIKE 'm:%'").one().c as number) : 0;
    return json({ rev: this.rev, db: { users, convs, msgs, stories, audit }, msgCount });
  }

  private admins() {
    return this.all("u:").filter((u) => u.role === "admin" && u.status === "active").length;
  }

  // Alle Schreibzugriffe laufen hier durch – mit Rechteprüfung pro Aktion.
  private op(me: Row, b: Row): Response | void {
    const n = me.username as string;
    const need = (c: boolean, msg = "Nicht erlaubt.") => {
      if (!c) throw new Error(msg);
    };
    const target = () => this.get<Row>(`u:${String(b.to ?? b.username)}`);
    const conv = (id: string) => {
      const c = this.get<Row>(`c:${id}`);
      need(!!c && c.members.includes(n));
      return c!;
    };
    const admin = () => need(me.role === "admin");
    switch (b.op) {
      case "touch": {
        me.lastSeen = Date.now();
        return this.put(`u:${n}`, me);
      }
      case "startConv": {
        const t = target();
        need(!!t && t.status === "active", "Nutzer nicht gefunden.");
        this.ensureConv(n, t!.username);
        return;
      }
      case "sendMsg": {
        const t = target();
        need(!!t && t.status === "active", "Nutzer nicht gefunden.");
        need(typeof b.ct === "string" && b.ct.length < 1_500_000 && typeof b.iv === "string", "Nachricht zu groß.");
        const c = this.ensureConv(n, t!.username);
        const ts = Date.now();
        const id = String(b.id ?? uid()).slice(0, 24);
        if (c.ttl) this.arm();
        this.put(`m:${id}`, { id, conv: c.id, from: n, to: t!.username, iv: b.iv, ct: b.ct, ts, exp: c.ttl ? ts + c.ttl * 1000 : null, read: false, rr: false, ...(b.once ? { once: true } : {}) });
        return;
      }
      case "markRead": {
        conv(b.conv);
        for (const m of this.all("m:")) if (m.conv === b.conv && m.to === n && !m.read) this.put(`m:${m.id}`, { ...m, read: true, rr: !!b.receipt });
        return;
      }
      case "setTtl": {
        const c = conv(b.conv);
        const ttl = Math.max(0, Number(b.ttl) || 0);
        this.put(`c:${c.id}`, { ...c, ttl });
        if (ttl) {
          for (const m of this.all("m:")) {
            if (m.conv === c.id) this.put(`m:${m.id}`, { ...m, exp: Math.min(m.exp ?? Infinity, m.ts + ttl * 1000) });
          }
          this.arm();
        }
        return;
      }
      case "clearConv": {
        conv(b.conv);
        for (const m of this.all("m:")) if (m.conv === b.conv) this.del(`m:${m.id}`);
        return;
      }
      case "consumeOnce": {
        const m = this.get<Row>(`m:${b.id}`);
        if (m && m.to === n && m.once && !m.opened) this.put(`m:${m.id}`, { ...m, opened: true, iv: "", ct: "" });
        return;
      }
      case "updateProfile": {
        const p = b.profile ?? {};
        if (typeof p.name === "string") me.name = p.name.trim().slice(0, 40) || n;
        if (typeof p.bio === "string") me.bio = p.bio.slice(0, 140);
        if (typeof p.mood === "string") me.mood = p.mood.slice(0, 8);
        if (p.avatar === null) delete me.avatar;
        else if (typeof p.avatar === "string") {
          need(p.avatar.length < 200_000, "Bild zu groß.");
          me.avatar = p.avatar;
        }
        return this.put(`u:${n}`, me);
      }
      case "updatePrefs": {
        const p = b.prefs ?? {};
        for (const k of ["receipts", "blurOnBlur", "showSeen"]) if (typeof p[k] === "boolean") me.prefs[k] = p[k];
        return this.put(`u:${n}`, me);
      }
      case "postStory": {
        const sid = uid();
        const ts = Date.now();
        const partners = new Set<string>([n]);
        this.all("c:").filter((c) => c.members.includes(n)).forEach((c) => c.members.forEach((m: string) => partners.add(m)));
        for (const e of b.entries ?? []) {
          need(partners.has(e.to) && typeof e.ct === "string" && e.ct.length < 1_500_000);
          const id = uid();
          this.put(`s:${id}`, { id, sid, author: n, to: e.to, iv: e.iv, ct: e.ct, ts, exp: ts + 86400000, seen: e.to === n });
        }
        return;
      }
      case "markStorySeen": {
        const s = this.get<Row>(`s:${b.id}`);
        if (s && s.to === n) this.put(`s:${s.id}`, { ...s, seen: true });
        return;
      }
      case "deleteStory": {
        for (const s of this.all("s:")) if (s.sid === b.sid && s.author === n) this.del(`s:${s.id}`);
        return;
      }
      case "deleteSelf": {
        need(me.role !== "admin" || this.admins() > 1, "Du bist der letzte Administrator.");
        this.purgeUser(n);
        return this.log(n, "user.self_delete", "@" + n);
      }
      case "setStatus":
      case "setRole":
      case "deleteUser": {
        admin();
        const t = target();
        need(!!t);
        need(t!.username !== n, "Das geht nicht für dein eigenes Konto.");
        if (b.op === "setStatus") {
          need(b.status === "active" || b.status === "suspended");
          this.put(`u:${t!.username}`, { ...t, status: b.status });
          return this.log(n, b.status === "suspended" ? "user.suspend" : "user.reactivate", "@" + t!.username);
        }
        if (b.op === "setRole") {
          need(b.role === "admin" || b.role === "user");
          this.put(`u:${t!.username}`, { ...t, role: b.role });
          return this.log(n, "user.role", `@${t!.username} → ${b.role}`);
        }
        this.purgeUser(t!.username);
        return this.log(n, "user.delete", "@" + t!.username);
      }
      case "resetInstance": {
        admin();
        this.ctx.storage.sql.exec("DELETE FROM kv WHERE k NOT IN ('rev','accessCodeHash')");
        return;
      }
      default:
        throw new Error("Unbekannte Aktion.");
    }
  }
}
